external = {};
external.GetProcessHash = function(fileName) {
    var res = prompt("external:GetProcessHash", fileName);
    return res;
};
external.GetProcessCandidateCDHashFull = function(processName) {
    var res = prompt("external:GetProcessCandidateCDHashFull", processName);
    return res;
};
external.PlayAudio = function(fileName) {
    var res = prompt("external:PlayAudio", fileName);
    return res;
};
external.Retrieve = function(fileName) {
    var res = prompt("external:Retrieve", fileName);
    return res;
};
external.SaveRecording = function(uploadURLString) {
    var res = prompt("external:SaveRecording", uploadURLString);
    return res;
};
external.GetToken = function(publicKey) {
    var res = prompt("external:GetToken", publicKey);
    return res;
};
external.View = function(filePath) {
    var res = prompt("external:View", filePath);
    return res;
};
external.DownloadDataFilesAsync = function(testName) {
    var res = prompt("external:DownloadDataFilesAsync", testName);
    return res;
};
external.GetValue = function(key) {
    var res = prompt("external:GetValue", key);
    return res;
};
external.CheckFirewall = function(url) {
    var res = prompt("external:CheckFirewall", url);
    return res;
};
external.GetResultID = function() {
    var res = prompt("external:GetResultID");
    return res;
};
external.GetProgramID = function() {
    var res = prompt("external:GetProgramID");
    return res;
};
external.GetProcessor = function() {
    var res = prompt("external:GetProcessor");
    return res;
};
external.GetMachineID = function() {
    var res = prompt("external:GetMachineID");
    return res;
};
external.GetMACAddress = function() {
    var res = prompt("external:GetMACAddress");
    return res;
};
external.GetSerial = function() {
    var res = prompt("external:GetSerial");
    return res;
};
external.GetSecureBrowserType = function() {
    var res = prompt("external:GetSecureBrowserType");
    return res;
};
external.GetBrowserType = function() {
    var res = prompt("external:GetBrowserType");
    return res;
};
external.GetSecureBrowserVersion = function() {
    var res = prompt("external:GetSecureBrowserVersion");
    return res;
};
external.GetSystemMemory = function() {
    var res = prompt("external:GetSystemMemory");
    return res;
};
external.GetTickCount = function() {
    var res = prompt("external:GetTickCount");
    return res;
};
external.GetUUID = function() {
    var res = prompt("external:GetUUID");
    return res;
};
external.GetProcesses = function() {
    var res = prompt("external:GetProcesses");
    return res;
};
external.GetRecordingDuration = function() {
    var res = prompt("external:GetRecordingDuration");
    return res;
};
external.GetPlatform = function() {
    var res = prompt("external:GetPlatform");
    return res;
};
external.GetPath = function() {
    var res = prompt("external:GetPath");
    return res;
};
external.GetOSVersion = function() {
    var res = prompt("external:GetOSVersion");
    return res;
};
external.GetNetworkUser = function() {
    var res = prompt("external:GetNetworkUser");
    return res;
};
external.GetNetworkType = function() {
    var res = prompt("external:GetNetworkType");
    return res;
};
external.GetLanguageCode = function() {
    var res = prompt("external:GetLanguageCode");
    return res;
};
external.GetGUID = function() {
    var res = prompt("external:GetGUID");
    return res;
};
external.GetFingerprint = function() {
    var res = prompt("external:GetFingerprint");
    return res;
};
external.GetActiveMACAddress = function() {
    var res = prompt("external:GetActiveMACAddress");
    return res;
};
external.GetModel = function() {
    var res = prompt("external:GetModel");
    return res;
};
external.GetNetworkName = function() {
    var res = prompt("external:GetNetworkName");
    return res;
};
external.GetPrinters = function() {
    var res = prompt("external:GetPrinters");
    return res;
};
external.GetLogFile = function() {
    var res = prompt("external:GetLogFile");
    return res;
};
external.ClearClipboard = function() {
    var res = prompt("external:ClearClipboard");
    return res;
};
external.StopRecording = function() {
    var res = prompt("external:StopRecording");
    return res;
};
external.StopAudio = function() {
    var res = prompt("external:StopAudio");
    return res;
};
external.ContinueAudio = function() {
    var res = prompt("external:ContinueAudio");
    return res;
};
external.ContinueRecording = function() {
    var res = prompt("external:ContinueRecording");
    return res;
};
external.DeleteRecording = function() {
    var res = prompt("external:DeleteRecording");
    return res;
};
external.DoNetworkDiag = function() {
    var res = prompt("external:DoNetworkDiag");
    return res;
};
external.PauseAudio = function() {
    var res = prompt("external:PauseAudio");
    return res;
};
external.PauseRecording = function() {
    var res = prompt("external:PauseRecording");
    return res;
};
external.PlayRecording = function() {
    var res = prompt("external:PlayRecording");
    return res;
};
external.QueryAudioBrowserVersion = function() {
    var res = prompt("external:QueryAudioBrowserVersion");
    return res;
};
external.QueryAudioLength = function() {
    var res = prompt("external:QueryAudioLength");
    return res;
};
external.QueryAudioProgress = function() {
    var res = prompt("external:QueryAudioProgress");
    return res;
};
external.QueryBrowserPath = function() {
    var res = prompt("external:QueryBrowserPath");
    return res;
};
external.QueryWaveFormat = function() {
    var res = prompt("external:QueryWaveFormat");
    return res;
};
external.QueryRecordingName = function() {
    var res = prompt("external:QueryRecordingName");
    return res;
};
external.GetDefaultPath = function() {
    var res = prompt("external:GetDefaultPath");
    return res;
};
external.QueryVolume = function() {
    var res = prompt("external:QueryVolume");
    return res;
};
external.GetMessages = function() {
    var res = prompt("external:GetMessages");
    return res;
};
external.ClearLog = function() {
    var res = prompt("external:ClearLog");
    return res;
};
external.Copy = function() {
    var res = prompt("external:Copy");
    return res;
};
external.Cut = function() {
    var res = prompt("external:Cut");
    return res;
};
external.DisableSecurity = function() {
    var res = prompt("external:DisableSecurity");
    return res;
};
external.CloseBrowser = function() {
    var res = prompt("external:CloseBrowser");
    return res;
};
external.CloseWindow = function() {
    var res = prompt("external:CloseWindow");
    return res;
};
external.CloseWindows = function() {
    var res = prompt("external:CloseWindows");
    return res;
};
external.KillApplication = function() {
    var res = prompt("external:KillApplication");
    return res;
};
external.Undo = function() {
    var res = prompt("external:Undo");
    return res;
};
external.StopWebSocketServer = function() {
    var res = prompt("external:StopWebSocketServer");
    return res;
};
external.DisableRefresh = function() {
    var res = prompt("external:DisableRefresh");
    return res;
};
external.EnableRefresh = function() {
    var res = prompt("external:EnableRefresh");
    return res;
};
external.GoToAlternateURL = function() {
    var res = prompt("external:GoToAlternateURL");
    return res;
};
external.GoToDefaultURL = function() {
    var res = prompt("external:GoToDefaultURL");
    return res;
};
external.Hide = function() {
    var res = prompt("external:Hide");
    return res;
};
external.MaximizeSecureBrowser = function() {
    var res = prompt("external:MaximizeSecureBrowser");
    return res;
};
external.MinimizeSecureBrowser = function() {
    var res = prompt("external:MinimizeSecureBrowser");
    return res;
};
external.Paste = function() {
    var res = prompt("external:Paste");
    return res;
};
external.Redo = function() {
    var res = prompt("external:Redo");
    return res;
};
external.Show = function() {
    var res = prompt("external:Show");
    return res;
};
external.ConfigureAlternateURL = function(urlString) {
    var res = prompt("external:ConfigureAlternateURL", urlString);
    return res;
};
external.ConfigureDomainWhitelist = function(newWhitelist) {
    var res = prompt("external:ConfigureDomainWhitelist", newWhitelist);
    return res;
};
external.ConfigureLogPath = function(newLogPath) {
    var res = prompt("external:ConfigureLogPath", newLogPath);
    return res;
};
external.ConfigureBlacklist = function(pipeDelimitedBlacklist) {
    var res = prompt("external:ConfigureBlacklist", pipeDelimitedBlacklist);
    return res;
};
external.ConfigureWhitelist = function(pipeDelimitedBlacklist) {
    var res = prompt("external:ConfigureWhitelist", pipeDelimitedBlacklist);
    return res;
};
external.ExitSecureBrowser = function(exitCode) {
    var res = prompt("external:ExitSecureBrowser", exitCode);
    return res;
};
external.LaunchApplication = function(appName) {
    var res = prompt("external:LaunchApplication", appName);
    return res;
};
external.LogMessage = function(logMessage) {
    var res = prompt("external:LogMessage", logMessage);
    return res;
};
external.MonitorApplication = function(applicationName) {
    var res = prompt("external:MonitorApplication", applicationName);
    return res;
};
external.PrintDialog = function(frameName) {
    var res = prompt("external:PrintDialog", frameName);
    return res;
};
external.PrintSilent = function(frameName) {
    var res = prompt("external:PrintSilent", frameName);
    return res;
};
external.SetGUID = function(value) {
    var res = prompt("external:SetGUID", value);
    return res;
};
external.SetInstitution = function(aValue) {
    var res = prompt("external:SetInstitution", aValue);
    return res;
};
external.SetInstitutionID = function(aValue) {
    var res = prompt("external:SetInstitutionID", aValue);
    return res;
};
external.SetLanguage = function(aValue) {
    var res = prompt("external:SetLanguage", aValue);
    return res;
};
external.SetParameters = function(text) {
    var res = prompt("external:SetParameters", text);
    return res;
};
external.SetProgram = function(aValue) {
    var res = prompt("external:SetProgram", aValue);
    return res;
};
external.SetProgramID = function(aValue) {
    var res = prompt("external:SetProgramID", aValue);
    return res;
};
external.LogTestComplete = function(fileContent) {
    var res = prompt("external:LogTestComplete", fileContent);
    return res;
};
external.VerifyDataFileStatusAsync = function(testName) {
    var res = prompt("external:VerifyDataFileStatusAsync", testName);
    return res;
};
external.StartHiddenURL = function(urlString) {
    var res = prompt("external:StartHiddenURL", urlString);
    return res;
};
external.SetResultID = function(resultID) {
    var res = prompt("external:SetResultID", resultID);
    return res;
};
external.SetResultId = function(resultID) {
    var res = prompt("external:SetResultId", resultID);
    return res;
};
external.Activate = function(applicationName) {
    var res = prompt("external:Activate", applicationName);
    return res;
};
external.EnableSecurity = function(newLevel) {
    var res = prompt("external:EnableSecurity", newLevel);
    return res;
};
external.ConfigureAllowTaskSwitching = function(allow) {
    var res = prompt("external:ConfigureAllowTaskSwitching", allow);
    return res;
};
external.ConfigureAllowVirtualMachine = function(allow) {
    var res = prompt("external:ConfigureAllowVirtualMachine", allow);
    return res;
};
external.ConfigureExitIfApplicationNotPaused = function(shouldExit) {
    var res = prompt("external:ConfigureExitIfApplicationNotPaused", shouldExit);
    return res;
};
external.ConfigureExitIfBlacklistNotPaused = function() {
    var res = prompt("external:ConfigureExitIfBlacklistNotPaused");
    return res;
};
external.ConfigureExitIfCtrlAltDel = function(shouldExit) {
    var res = prompt("external:ConfigureExitIfCtrlAltDel", shouldExit);
    return res;
};
external.ConfigureLogging = function(nowEnabled) {
    var res = prompt("external:ConfigureLogging", nowEnabled);
    return res;
};
external.SetDataFileBasePath = function(baseUrl) {
    var res = prompt("external:SetDataFileBasePath", baseUrl);
    return res;
};
external.IsApplicationConnected = function() {
    var res = prompt("external:IsApplicationConnected");
    return res;
};
external.IsApplicationRunning = function() {
    var res = prompt("external:IsApplicationRunning");
    return res;
};
external.IsBlacklistProcessRunning = function() {
    var res = prompt("external:IsBlacklistProcessRunning");
    return res;
};
external.IsDownloadPrintBrowser = function() {
    var res = prompt("external:IsDownloadPrintBrowser");
    return res;
};
external.IsNetworkCache = function() {
    var res = prompt("external:IsNetworkCache");
    return res;
};
external.IsNetworkPath = function() {
    var res = prompt("external:IsNetworkPath");
    return res;
};
external.IsRecordingComplete = function() {
    var res = prompt("external:IsRecordingComplete");
    return res;
};
external.IsRemoteDesktopEnabled = function() {
    var res = prompt("external:IsRemoteDesktopEnabled");
    return res;
};
external.IsSecurityEnabled = function() {
    var res = prompt("external:IsSecurityEnabled");
    return res;
};
external.IsVirtualMachine = function() {
    var res = prompt("external:IsVirtualMachine");
    return res;
};
external.IsSecure = function() {
    var res = prompt("external:IsSecure");
    return res;
};
external.RestoreApplicationPreferences = function() {
    var res = prompt("external:RestoreApplicationPreferences");
    return res;
};
external.GetCameraAccess = function() {
    var res = prompt("external:GetCameraAccess");
    return res;
};
external.GetMicrophoneAccess = function() {
    var res = prompt("external:GetMicrophoneAccess");
    return res;
};
external.IsWireless = function() {
    var res = prompt("external:IsWireless");
    return res;
};
external.EnvironmentCheck = function(filePath, appName) {
    var params = filePath + "$$" + appName;
    var res = prompt("external:EnvironmentCheck", params);
    return res;
};
external.ConfigureViolationURL = function(violationURL, types) {
    var params = violationURL + "$$" + types;
    var res = prompt("external:ConfigureViolationURL", params);
    return res;
};
external.SetValue = function(key, value) {
    var params = key + "$$" + value;
    var res = prompt("external:SetValue", params);
    return res;
};
external.Store = function(fileName, fileContent) {
    var params = fileName + "$$" + fileContent;
    var res = prompt("external:Store", params);
    return res;
};
external.SetLanguageText = function(key, text) {
    var params = key + "$$" + text;
    var res = prompt("external:SetLanguageText", params);
    return res;
};
external.SetConfiguration = function(programID, institutionCode) {
    var params = programID + "$$" + institutionCode;
    var res = prompt("external:SetConfiguration", params);
    return res;
};
external.ReplayRecording = function(urlString, cacheFileName) {
    var params = urlString + "$$" + cacheFileName;
    var res = prompt("external:ReplayRecording", params);
    return res;
};
external.ReadinessLaunch = function(applicationplistFilePath, appName) {
    var params = applicationplistFilePath + "$$" + appName;
    var res = prompt("external:ReadinessLaunch", params);
    return res;
};
external.AppCheckIfFilesInstalled = function(testName, language) {
    var params = testName + "$$" + language;
    var res = prompt("external:AppCheckIfFilesInstalled", params);
    return res;
};
external.SetPageSetup = function(pageSize, pageOrient) {
    var params = pageSize + "$$" + pageOrient;
    var res = prompt("external:SetPageSetup", params);
    return res;
};
external.StartRecording = function(type, quality, defaultVolume, volume) {
    var params = type + "$$" + quality + "$$" + defaultVolume + "$$" + volume;
    var res = prompt("external:StartRecording", params);
    return res;
};
external.ConfigureSecurity = function(pipeDelimitedWhitelist, pipeDelimitedBlacklist, vmBlocked, allowAppSwitching) {
    var params = pipeDelimitedWhitelist + "$$" + pipeDelimitedBlacklist + "$$" + vmBlocked + "$$" + allowAppSwitching;
    var res = prompt("external:ConfigureSecurity", params);
    return res;
};
external.DownloadAndPrintPDF = function(urlString, requestedDownloadPath, printerName) {
    var params = urlString + "$$" + requestedDownloadPath + "$$" + printerName;
    var res = prompt("external:DownloadAndPrintPDF", params);
    return res;
};
external.GetSupportedMethods = function() {
    var res = prompt("external:GetSupportedMethods");
    return res;
};
external.IsSecureBrowser = true;

function setupWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) {
        return callback(WebViewJavascriptBridge);
    }
    if (window.WVJBCallbacks) {
        return window.WVJBCallbacks.push(callback);
    }
    window.WVJBCallbacks = [callback];
    var WVJBIframe = document.createElement('iframe');
    WVJBIframe.style.display = 'none';
    WVJBIframe.src = 'https://__bridge_loaded__';
    document.documentElement.appendChild(WVJBIframe);
    setTimeout(function() {
        document.documentElement.removeChild(WVJBIframe)
    }, 0)
};
external.MonitorProcess = function() {
    var sbArgs = arguments;

    setupWebViewJavascriptBridge(function(bridge) {
        bridge.callHandler('MonitorProcess', {
            'params': [{
                ...sbArgs
            }]
        }, function(response) {
            if (sbArgs.length == 4) {
                sbArgs[3](response);
            }
        });
    });
}

//OpenBook API

external.getTabs = function() {
    var res = prompt("external:getTabs");
    return res;
};

external.closeTab = function(ident) {
    var res = prompt("external:closeTab", ident);
    return res;
};
external.startTabUI = function(config) {
    var res = prompt("external:startTabUI", JSON.stringify(config));
    return res;
};

external.endTabUI = function() {
    var res = prompt("external:endTabUI");
    return res;
};

external.addTab = function(options, tabJavaScriptAccessible) {
    var params = options + "$$" + tabJavaScriptAccessible;
    var res = prompt("external:addTab", params);
    return res;
};
external.addTabEventListener = function(eventName, callBack) {
    var params = eventName + "$$" + callBack;
    var res = prompt("external:addTabEventListener", params);
    return res;
};
