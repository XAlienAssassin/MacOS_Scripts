#!/usr/bin/env python3
"""
Look up full detail (parameters, request body, response schema) for one or more
Jamf API endpoints from the bundled specs.

Covers BOTH Jamf APIs:
  - Pro API   (jamf-pro-api-openapi.json)      — OpenAPI 3.0, JSON, OAuth2 client-credentials
  - Classic API (jamf-classic-api-swagger.yaml) — Swagger 2.0, XML/JSON, basic auth or bearer

The Pro spec is ~2MB and the Classic spec ~240KB — both too large to read wholesale.
Use this script to pull out just the endpoint(s) you need.

Usage:
  python3 query_jamf_api.py --search redeploy                     # search both specs
  python3 query_jamf_api.py --search redeploy --api pro            # search pro only
  python3 query_jamf_api.py --search computergroups --api classic  # search classic only
  python3 query_jamf_api.py --api pro --path /v1/jamf-management-framework/redeploy/{id}
  python3 query_jamf_api.py --api classic --path /computergroups/id/{id} --method put

Run with no args for usage help.
"""
import json
import argparse
import os
import sys

BASE = os.path.join(os.path.dirname(__file__), "..", "references", "api")
PRO_SPEC_PATH = os.path.join(BASE, "jamf-pro-api-openapi.json")
CLASSIC_SPEC_PATH = os.path.join(BASE, "jamf-classic-api-swagger.yaml")

HTTP_METHODS = ("get", "post", "put", "patch", "delete")


def load_pro():
    with open(PRO_SPEC_PATH) as f:
        return json.load(f)


def load_classic():
    import yaml
    with open(CLASSIC_SPEC_PATH) as f:
        return yaml.safe_load(f)


def resolve_schema_openapi3(schema, components, depth=0, seen=None):
    """Resolve $ref pointers for OpenAPI 3.0 (components/schemas/...)."""
    if seen is None:
        seen = set()
    if depth > 6 or not isinstance(schema, dict):
        return schema
    if "$ref" in schema:
        name = schema["$ref"].split("/")[-1]
        if name in seen:
            return {"$ref (circular)": name}
        target = components.get("schemas", {}).get(name, {})
        return resolve_schema_openapi3(target, components, depth + 1, seen | {name})
    if schema.get("type") == "object" and "properties" in schema:
        return {k: resolve_schema_openapi3(v, components, depth + 1, seen) for k, v in schema["properties"].items()}
    if schema.get("type") == "array" and "items" in schema:
        return [resolve_schema_openapi3(schema["items"], components, depth + 1, seen)]
    out = {}
    for key in ("type", "description", "example", "enum", "format"):
        if key in schema:
            out[key] = schema[key]
    return out or schema.get("type", "any")


def resolve_schema_swagger2(schema, defs, depth=0, seen=None):
    """Resolve $ref pointers for Swagger 2.0 (definitions/...)."""
    if seen is None:
        seen = set()
    if depth > 6 or not isinstance(schema, dict):
        return schema
    if "$ref" in schema:
        name = schema["$ref"].split("/")[-1]
        if name in seen:
            return {"$ref (circular)": name}
        target = defs.get(name, {})
        return resolve_schema_swagger2(target, defs, depth + 1, seen | {name})
    if schema.get("type") == "object" and "properties" in schema:
        return {k: resolve_schema_swagger2(v, defs, depth + 1, seen) for k, v in schema["properties"].items()}
    if schema.get("type") == "array" and "items" in schema:
        return [resolve_schema_swagger2(schema["items"], defs, depth + 1, seen)]
    out = {}
    for key in ("type", "description", "example", "enum", "format"):
        if key in schema:
            out[key] = schema[key]
    return out or schema.get("type", "any")


def show_path_pro(spec, path, method=None):
    paths = spec["paths"]
    components = spec.get("components", {})
    if path not in paths:
        matches = [p for p in paths if path in p]
        print(f"[Pro API] Path '{path}' not found exactly.")
        if matches:
            print("Did you mean one of these?")
            for m in matches[:15]:
                print(" -", m)
        return
    for m, mdef in paths[path].items():
        if m not in HTTP_METHODS:
            continue
        if method and m.lower() != method.lower():
            continue
        print(f"\n{'=' * 70}\n[Pro API] {m.upper()} {path}\n{'=' * 70}")
        if mdef.get("summary"):
            print("Summary:", mdef["summary"])
        params = mdef.get("parameters", [])
        if params:
            print("\n-- Parameters --")
            for p in params:
                print(f"  [{p.get('in','?')}] {p.get('name','?')}"
                      f"{' (required)' if p.get('required') else ''}: {p.get('description','')}")
        body = mdef.get("requestBody", {})
        if body:
            content = body.get("content", {})
            for ctype, cdef in content.items():
                schema = cdef.get("schema", {})
                resolved = resolve_schema_openapi3(schema, components)
                print(f"\n-- Request body ({ctype}) --")
                print(json.dumps(resolved, indent=2)[:3000])
        responses = mdef.get("responses", {})
        ok = responses.get("200") or responses.get("201")
        if ok:
            content = ok.get("content", {})
            for ctype, cdef in content.items():
                schema = cdef.get("schema", {})
                resolved = resolve_schema_openapi3(schema, components)
                print(f"\n-- 200/201 Response ({ctype}) --")
                print(json.dumps(resolved, indent=2)[:3000])


def show_path_classic(spec, path, method=None):
    paths = spec["paths"]
    defs = spec.get("definitions", {})
    if path not in paths:
        matches = [p for p in paths if path in p]
        print(f"[Classic API] Path '{path}' not found exactly.")
        if matches:
            print("Did you mean one of these?")
            for m in matches[:15]:
                print(" -", m)
        return
    for m, mdef in paths[path].items():
        if m not in HTTP_METHODS:
            continue
        if method and m.lower() != method.lower():
            continue
        print(f"\n{'=' * 70}\n[Classic API] {m.upper()} {path}\n{'=' * 70}")
        if mdef.get("summary"):
            print("Summary:", mdef["summary"])
        if mdef.get("description"):
            print("Description:", mdef["description"])
        params = mdef.get("parameters", [])
        if params:
            print("\n-- Parameters --")
            for p in params:
                if "schema" in p:
                    resolved = resolve_schema_swagger2(p["schema"], defs)
                    print(f"  [{p.get('in','?')}] {p.get('name','body')} (body):")
                    print(json.dumps(resolved, indent=4)[:2000])
                else:
                    print(f"  [{p.get('in','?')}] {p.get('name','?')}"
                          f"{' (required)' if p.get('required') else ''} "
                          f"({p.get('type','')}): {p.get('description','')}")
        print("\nNote: the Classic API often documents XML bodies loosely (see 'description'")
        print("field above for hints like <computer_additions>/<computer_deletions>) rather")
        print("than a strict schema — cross-check with Jamf's own docs/UI when unsure.")


def search(pro_spec, classic_spec, term, api_filter=None):
    term = term.lower()
    if pro_spec and api_filter in (None, "pro"):
        hits = [p for p in pro_spec["paths"] if term in p.lower()]
        print(f"[Pro API] {len(hits)} path(s) matching '{term}':")
        for p in sorted(hits):
            methods = ", ".join(m.upper() for m in pro_spec["paths"][p] if m in HTTP_METHODS)
            print(f"  {p}  [{methods}]")
        print()
    if classic_spec and api_filter in (None, "classic"):
        hits = [p for p in classic_spec["paths"] if term in p.lower()]
        print(f"[Classic API] {len(hits)} path(s) matching '{term}':")
        for p in sorted(hits):
            methods = ", ".join(m.upper() for m in classic_spec["paths"][p] if m in HTTP_METHODS)
            print(f"  {p}  [{methods}]")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--path", help="Exact API path to inspect, e.g. /v1/computers-inventory or /computergroups/id/{id}")
    ap.add_argument("--method", help="Restrict to one HTTP method (get/post/put/patch/delete)")
    ap.add_argument("--search", help="Search for paths containing this substring")
    ap.add_argument("--api", choices=["pro", "classic"], help="Restrict to one API. If omitted with --path, tries pro then classic.")
    args = ap.parse_args()

    if not args.path and not args.search:
        ap.print_help()
        sys.exit(0)

    if args.search:
        pro_spec = load_pro() if args.api in (None, "pro") else None
        classic_spec = load_classic() if args.api in (None, "classic") else None
        search(pro_spec, classic_spec, args.search, args.api)

    if args.path:
        if args.api == "classic":
            show_path_classic(load_classic(), args.path, args.method)
        elif args.api == "pro":
            show_path_pro(load_pro(), args.path, args.method)
        else:
            # try pro first, then classic
            pro_spec = load_pro()
            if args.path in pro_spec["paths"]:
                show_path_pro(pro_spec, args.path, args.method)
            else:
                classic_spec = load_classic()
                if args.path in classic_spec["paths"]:
                    show_path_classic(classic_spec, args.path, args.method)
                else:
                    print(f"'{args.path}' not found in either spec. Try --search first.")


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:
        sys.stderr.close()
        sys.exit(0)
