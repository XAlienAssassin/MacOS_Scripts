---
name: jamf-api
description: Reference material for the Jamf Pro API (modern OpenAPI 3.0, 550 endpoints, OAuth2/JSON) and the Jamf Classic API (legacy Swagger 2.0, 273 endpoints, XML-first, base path /JSSResource/), both pulled from this user's own Jamf Pro tenant. Use whenever the user asks about Jamf API endpoints, request/response fields, authentication (API Roles & Clients, OAuth2 client credentials, basic auth, bearer tokens), computer inventory, computer groups (static/smart), advanced computer searches, computer history, MDM commands, or the Jamf Management Framework (redeploy/binary). Also use for questions about connecting Jamf to Hyperautomation or other external tools, or when building/debugging any workflow, script, or integration that calls Jamf's API. Trigger even without the word "Jamf Pro" or "API" explicitly — e.g. "add a computer to a static group", "check when a Mac last checked in", "redeploy the management framework", "what fields does computers-inventory return".
---

# Jamf API Reference (Pro + Classic)

This skill bundles the user's own Jamf Pro tenant's API specifications, covering both
generations of Jamf's API. It complements the `sentinelone-hyperautomation` skill — the two
are used together when building workflows that bridge SentinelOne detections into
Jamf-managed macOS devices.

## User's environment context

- macOS devices are managed via **Jamf Pro**. Windows devices via Microsoft Intune (see
  `it-admin-context` / `sentinelone-hyperautomation` skills for that side).
- Jamf is connected to SentinelOne Singularity Hyperautomation via an **OAuth 2.0 client
  credentials** connection (API Role + API Client, not legacy basic-auth API users).
- Active project: a Hyperautomation port of `RedeployJamfBinaryByHistory.sh` — a workflow
  that finds Macs whose Jamf binary has gone dark but whose MDM channel is still
  responsive, and redeploys the management framework, gated behind an email
  approval (Create Interaction / Wait for Interaction). It also auto-adds
  permanently-unresponsive computers to a `Redeploy - Permanently Excluded` static group
  so they stop generating daily approval requests. See
  `references/api/key-endpoints.md` for every endpoint this specific workflow touches,
  already verified against the real spec.

## Two APIs — know which one you're using

| | Pro API | Classic API |
|---|---|---|
| Format | OpenAPI 3.0, JSON | Swagger 2.0, XML-first (JSON also supported) |
| Base path | versioned (`/v1/`, `/v2/`... up to `/v4/` on some resources) | `/JSSResource/` |
| Auth | OAuth 2.0 client credentials (`/v1/oauth/token`), or basic-auth token exchange (`/v1/auth/token`) | Bearer token (can reuse a Pro API token) or basic auth |
| Covers | Newer/actively-developed resources; multiple API versions per resource (e.g. `/v1` through `/v4` computers-inventory, each adding fields/actions) | Older resources, some **Classic-only** with no Pro equivalent yet: Advanced Computer Searches, static/smart Computer Groups, Computer History |
| Spec file | `references/api/jamf-pro-api-openapi.json` (~2MB, 550 endpoints) | `references/api/jamf-classic-api-swagger.yaml` (~240KB, 273 endpoints) |

**Rule of thumb:** check the Pro API first for anything new; fall back to Classic for
searches, static groups, and history, since those haven't been fully ported yet as of this
spec snapshot.

## How to use the bundled references

Don't load the raw specs directly — they're large. Use these in order:

1. **`references/api/key-endpoints.md`** — curated, already-verified detail for the
   redeploy/exclusion workflow. Check this first; it covers auth, computer history, computer
   inventory, the redeploy action, and static group membership, plus a flagged list of
   destructive endpoints.
2. **`references/api/pro-api-endpoint-index.md`** / **`classic-api-endpoint-index.md`** —
   compact lists of every endpoint in each spec, grouped by resource, with method + summary.
   Use to find which endpoint covers something not in `key-endpoints.md`.
3. **`references/api/developer-guides.md`** — conceptual/prose docs pulled from
   developer.jamf.com that don't exist in the OpenAPI/Swagger specs at all: which-API-to-use
   guidance, Client Credentials/API Role mechanics (including whether a privilege change
   needs a client-secret rotation — it usually doesn't), RSQL filtering syntax, optimistic
   locking, and pointers to the two complete privilege tables below.
4. **`references/api/classic-api-privileges-complete.md`** — the **complete** Classic API
   privilege table (324 rows, every endpoint).
5. **`references/api/pro-api-privileges-complete.md`** — the **complete** Pro API privilege
   table (734 rows, every endpoint, plus deprecation dates). Both tables came from the user
   uploading each doc page's own `.md` export (append `.md` to the page URL, save, upload) —
   `web_fetch` alone truncates these pages partway through regardless of token limit, so
   this upload route is the way to get the rest of any doc page that truncates the same way.
6. **`scripts/query_jamf_api.py`** — for full parameter/schema detail on any single
   endpoint once you've found its path:

```bash
python3 scripts/query_jamf_api.py --search <keyword>                    # search both specs
python3 scripts/query_jamf_api.py --search <keyword> --api pro          # search one spec
python3 scripts/query_jamf_api.py --api pro --path /v1/<path>           # full detail
python3 scripts/query_jamf_api.py --api classic --path /<path> --method put
```

This resolves `$ref` schema pointers (OpenAPI 3.0 `components/schemas` or Swagger 2.0
`definitions`, handled correctly for each format) into readable inline JSON.

## Working conventions

- **Flag destructive actions** before wiring them into a workflow — device erase, MDM
  profile removal, record deletion, group/search deletion. See the flagged list in
  `key-endpoints.md`.
- **The Classic API is often loosely specified** — many endpoints (especially XML request
  bodies like computer group membership) only have their real shape documented in a free-text
  `description` field, not a strict schema. Say so explicitly when relaying one of these,
  and recommend testing against a single non-critical record before trusting it in a loop or
  bulk operation.
- **Cross-reference, don't guess.** Pull exact field names, endpoint paths, and parameter
  types from these bundled specs rather than general training knowledge — confirm with
  `query_jamf_api.py` before stating something as fact, the same way `key-endpoints.md` was
  built by querying the real spec rather than assuming.
- If something isn't covered in the bundled specs (a newer Jamf release, a resource added
  since this snapshot), say so plainly and suggest pulling a fresh spec export from
  **Jamf Pro → Settings → API Roles and Clients** (Pro API) or **`/api/schema/`** endpoints,
  the same way this bundle was sourced.
