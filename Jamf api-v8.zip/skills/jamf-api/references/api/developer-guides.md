# Jamf Developer Guides & Privilege Tables

Content pulled from developer.jamf.com — the conceptual/guide pages and privilege-mapping
tables that exist **only** as prose/HTML docs, not inside the OpenAPI/Swagger specs
(`jamf-pro-api-openapi.json`, `jamf-classic-api-swagger.yaml`). Don't re-fetch these pages
for well-known facts already captured here. The full privilege tables for both APIs are
bundled as separate files — `pro-api-privileges-complete.md` (734 rows) and
`classic-api-privileges-complete.md` (324 rows) — so any endpoint's required privilege
should be answerable from those two files without a live fetch.

## Contents
- [Which API should I use?](#which-api-should-i-use)
- [Client Credentials & API Roles](#client-credentials--api-roles)
- [Filtering with RSQL](#filtering-with-rsql)
- [Optimistic Locking](#optimistic-locking)
- [Pro API privilege table — now complete](#pro-api-privilege-table--now-complete)
- [Classic API privilege table — now complete](#classic-api-privilege-table--now-complete)

---

## Which API should I use?

Full page: https://developer.jamf.com/jamf-pro/docs/which-api-should-i-use

| | Classic API | Jamf Pro API |
|---|---|---|
| Authorization | OAuth (ROPC), OAuth (Client Credentials) | Same |
| Schema | Full XML; JSON only on GET | Full JSON |
| Filtering/Sorting/Pagination | No | Yes (RSQL — see below) |
| Endpoint Versioning | No | Yes (`v1`, `v2`, `v3`...) |

Jamf's own recommendation: **use the Pro API when the feature you need is supported
there**; fall back to Classic for anything not yet ported. A `preview` mode also exists on
some Pro API endpoints for early-access features — functional but subject to change before
becoming `v1`.

---

## Client Credentials & API Roles

Full page: https://developer.jamf.com/jamf-pro/docs/client-credentials

- **API Roles** are a collection of privileges; **API Clients** get one or more roles
  assigned, granting the cumulative privilege set. This is exactly the model this user's
  Hyperautomation Jamf connection uses.
- **Important operational note, directly relevant to fixing 403s on this project:**
  adding or removing a **privilege** from an existing API Role takes effect **immediately**
  for newly-generated access tokens — no need to rotate the client secret. Adding or
  removing an entire **API Role** from an API Client, however, *does* require rotating the
  client secret for the change to take effect. (So: the privilege fixes made during this
  project's build — Read Computers, the redeploy privileges, the static-group-update
  privilege — should all apply automatically the next time Hyperautomation requests a
  fresh token; no secret rotation needed for those.)
- Jamf publishes official Postman collections for both APIs (linked from the page above),
  built to work only with Postman **environment variables** (`client_id`, `client_secret`,
  `baseUrl`/`url`) — collection-level variables aren't supported. Given this project's
  OpenAPI/Swagger specs are already bundled and more directly useful for building
  Hyperautomation HTTP Request actions, these collections weren't imported separately —
  they're mentioned here in case Postman-based manual testing is ever wanted outside
  Hyperautomation.

---

## Filtering with RSQL

Full page: https://developer.jamf.com/jamf-pro/docs/filtering-with-rsql

Applies to Pro API `GET` endpoints that support filtering (e.g. could be used to filter
`/v1/computers-inventory` server-side instead of pulling everything and filtering in a
workflow condition — worth considering as an optimization for this project's search step
if the Advanced Computer Search approach is ever revisited).

| Operator | Example | Meaning |
|---|---|---|
| `==` | `general.assetTag=="ValueA"` | equals |
| `!=` | `general.assetTag!="ValueA"` | not equals |
| `=lt=` or `<` | `general.assetTag<"ValueA"` | less than |
| `=le=` or `<=` | `general.assetTag<="ValueA"` | less than or equal |
| `=gt=` or `>` | `general.assetTag>"ValueA"` | greater than |
| `=ge=` or `>=` | `general.assetTag>="ValueA"` | greater than or equal |
| `=in=` | `general.assetTag=in=(A,B)` | value is A or B |
| `=out=` | `general.assetTag=out=(A,B)` | value is not A or B |

Logical: `,` = OR, `;` = AND (AND evaluated first; use parentheses to override). String
comparisons are case-insensitive. Quote values containing spaces; escape embedded quotes
with `\`. Null values are excluded from matches; empty-string values are included.

---

## Optimistic Locking

Full page: https://developer.jamf.com/jamf-pro/docs/optimistic-locking

Only applies to **prestage** endpoints (`/v1/computer-prestages`, `/v1/mobile-device-prestages`,
`/v2/...`, `/v3/computer-prestages`, and their `/scope` sub-paths) — not used anywhere in
this project's redeploy/exclusion workflow, so just a pointer for if prestage automation is
ever added: these require reading the current `versionLock` value via GET first, then
including that exact value in the PUT/POST body; a stale value gets rejected as a conflict.

---

## Pro API privilege table — now complete

**Full table bundled separately**: `references/api/pro-api-privileges-complete.md`
(734 rows, covering `/auth` through `/v4/...` — the entire table, not an excerpt, plus
deprecation dates). Search that file directly for any Pro API endpoint's required
privilege rather than fetching the live page. Source:
https://developer.jamf.com/jamf-pro/docs/privileges-and-deprecations

Endpoints from this project already extracted into `key-endpoints.md` (with full context):
`/v1/computers-inventory` → `Read Computers`; `/v1/jamf-management-framework/redeploy/{id}`
→ `Send Computer Remote Command to Install Package` + `Read Computer Check-In`.

Other confirmed rows worth knowing for future workflow expansion:
- `/v1/computer-inventory/{id}/erase` `post` → `Send Computer Remote Wipe Command`
- `/v1/computer-inventory/{id}/remove-mdm-profile` `post` → `Send Computer Unmanage Command`
- `/v1/computers/{id}/recalculate-smart-groups` `post` → `Update Smart Computer Groups`
- `/v1/deploy-package` `post` → `Send Computer Remote Command to Install Package` (same
  privilege as the redeploy endpoint — makes sense, both are package-install commands)
- `/v1/computer-groups` (Pro API's newer group listing) `get` → `Read Smart Computer Groups`
  + `Read Static Computer Groups`
- `/v1/devices/{id}/groups` `get` → six different Read privileges depending on device/group
  type (Static/Smart × Computer/Mobile Device, plus base Read Computers/Read Mobile Devices)
- `/v1/conditional-access/device-compliance-information/computer/{deviceId}` `get` →
  `Read Device Compliance Information`
- `/v1/auth/token`, `/v1/auth`, `/v1/auth/invalidate-token`, `/v1/auth/keep-alive` → all
  `None` (no privilege required — makes sense, these are the auth bootstrap endpoints)

---

## Classic API privilege table — now complete

**Full table bundled separately**: `references/api/classic-api-privileges-complete.md`
(324 rows, `/accounts` through `/webhooks` — the entire table, not an excerpt). Search that
file directly for any Classic API endpoint's required privilege rather than fetching the
live page. Source: https://developer.jamf.com/jamf-pro/docs/classic-api-minimum-required-privileges-and-endpoint-mapping

Confirmed row for this project (already in `key-endpoints.md` too):
`/computergroups/id/{id}` `PUT` → `Update - Smart Computer Groups` (smart) or
`Update - Static Computer Groups` (static) — this user's exclusion group is static, so the
static privilege is what's actually required and confirmed working.

Other confirmed rows worth knowing:
- `/computerhistory/...` `GET` → `Read - Computers` (same privilege as basic computer read,
  not a separate "history" privilege — matches this project's working setup)
- `/computercheckin` `GET`/`PUT` → `Read - Check-In` / `Update - Check-In`
- `/advancedcomputersearches/id/{id}` all methods → `Read/Create/Update/Delete - Advanced
  Computer Searches` respectively (matches this project's search-step privilege)
- `/computers`, `/computers/id/{id}` (all methods) — **deprecated 2025-02-11**, Jamf
  recommends the Pro API's `/api/v1/computers-inventory` instead; not used in this project
  already since the Pro API endpoint was used from the start
- `/commandflush` `DELETE` → `Flush MDM Commands (Jamf Pro Server Actions)`
