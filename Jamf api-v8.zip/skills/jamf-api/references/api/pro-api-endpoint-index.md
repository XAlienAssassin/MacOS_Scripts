# Jamf Pro API — Endpoint Index

OpenAPI 3.0 spec, modern JSON REST API (`/api/...` and `/uapi/...` paths use version prefixes v1-v4). This is the API used for OAuth 2.0 client-credentials auth (API Roles & Clients) and JSON payloads.

Total endpoints: 550.

---

## account-groups

- `/v1/account-groups` — GET (Get account groups)
- `/v1/account-groups/{id}` — GET (Gets the account group.
)

## account-preferences

- `/v2/account-preferences` — GET (Get Jamf Pro account preferences
), PATCH (Update Jamf Pro account preferences
)
- `/v3/account-preferences` — GET (Get Jamf Pro account preferences
), PATCH (Update Jamf Pro account preferences
)

## accounts

- `/v1/accounts` — GET (Get user accounts), POST (Adds new account.
)
- `/v1/accounts/{id}` — DELETE (Deletes the user account.
), GET (Gets the user account.
), PUT (Updates the user account.
)

## activation-code

- `/v1/activation-code` — PUT (Updates Activation Code)
- `/v1/activation-code/history` — GET (Get Activation Code history object), POST (Add Activation Code object note
)
- `/v1/activation-code/history/export` — POST (Export history object collection in specified format for Activation Code
)
- `/v1/activation-code/organization-name` — PATCH (Updates Organization Name)

## adue-session-token-settings

- `/v1/adue-session-token-settings` — GET (Retrieve the Account Driven User Enrollment Session Token Settings
), PUT (Update Account Driven User Enrollment Session Token Settings.
)

## advanced-mobile-device-searches

- `/v1/advanced-mobile-device-searches` — GET (Get Advanced Search objects
), POST (Create Advanced Search object
)
- `/v1/advanced-mobile-device-searches/choices` — GET (Get Mobile Device Advanced Search criteria choices
)
- `/v1/advanced-mobile-device-searches/delete-multiple` — POST (Remove specified Advanced Search objects
)
- `/v1/advanced-mobile-device-searches/{id}` — DELETE (Remove specified Advanced Search object
), GET (Get specified Advanced Search object
), PUT (Get specified Advanced Search object
)

## advanced-user-content-searches

- `/v1/advanced-user-content-searches` — GET (Get All Advanced User Content Search objects
), POST (Create Advanced User Content Search object
)
- `/v1/advanced-user-content-searches/{id}` — DELETE (Remove specified Advanced User Content Search object
), GET (Get Specified Advanced User Content Search object
), PUT (Get Specified Advanced User Content Search object
)

## api-integrations

- `/v1/api-integrations` — GET (Get the current API Integrations), POST (Create API integration object)
- `/v1/api-integrations/{id}` — DELETE (Remove specified API integration), GET (Get specified API integration object), PUT (Update specified API integration object)
- `/v1/api-integrations/{id}/client-credentials` — POST (Create client credentials for specified API integration)

## api-role-privileges

- `/v1/api-role-privileges` — GET (Get the current Jamf API Role Privileges)
- `/v1/api-role-privileges/search` — GET (Search the current Jamf API Role Privileges)

## api-roles

- `/v1/api-roles` — GET (Get the current Jamf API Roles), POST (Create a new API role)
- `/v1/api-roles/{id}` — DELETE (Delete API Integrations Role), GET (Get the specific Jamf API Role), PUT (Update API Integrations Role)

## apns-client-push-status

- `/v1/apns-client-push-status` — GET (Search for clients with push notifications disabled
)
- `/v1/apns-client-push-status/enable-all-clients` — POST (Enable push notifications for all clients
)
- `/v1/apns-client-push-status/enable-all-clients/status` — GET (Get status of enable all clients request
)
- `/v1/apns-client-push-status/enable-client` — POST (Enable push notifications for a single client
)

## app-request

- `/v1/app-request/form-input-fields` — GET (Search for Form Input Fields
), POST (Create Form Input Field record
), PUT (Replace all Form Input Fields
)
- `/v1/app-request/form-input-fields/{id}` — DELETE (Remove specified Form Input Field record
), GET (Get specified Form Input Field object
), PUT (Update specified Form Input Field object
)
- `/v1/app-request/settings` — GET (Get Applicastion Request Settings
), PUT (Update Application Request Settings
)

## app-store-country-codes

- `/v1/app-store-country-codes` — GET (Return a list of Countries and the associated Codes
)

## auth

- `/auth` — GET (Get all the Authorization details associated with the current api
)
- `/auth/current` — POST (Get the authorization details associated with the current API token
)
- `/auth/invalidateToken` — POST (Invalidate current token
)
- `/auth/keepAlive` — POST (Invalidate existing token and generates new token
)
- `/v1/auth` — GET (Get all the Authorization details associated with the current api
)
- `/v1/auth/invalidate-token` — POST (Invalidate current token
)
- `/v1/auth/keep-alive` — POST (Invalidate existing token and generates new token
)
- `/v1/auth/token` — POST (Create a token based on other authentication details (basic, etc.))

## branding-images

- `/v1/branding-images/download/{id}` — GET (Download a self service branding image
)

## buildings

- `/v1/buildings` — GET (Search for sorted and paged Buildings
), POST (Create Building record
)
- `/v1/buildings/delete-multiple` — POST (Delete multiple Buildings by their ids
)
- `/v1/buildings/export` — POST (Export Buildings collection
)
- `/v1/buildings/{id}` — DELETE (Remove specified Building record
), GET (Get specified Building object
), PUT (Update specified Building object
)
- `/v1/buildings/{id}/history` — GET (Get specified Building History object
), POST (Add specified Building history object notes
)
- `/v1/buildings/{id}/history/export` — POST (Export history object collection in specified format for specified Buildings
)

## cache-settings

- `/v1/cache-settings` — GET (Get Cache Settings
), PUT (Update Cache Settings
)

## categories

- `/v1/categories` — GET (Get Category objects
), POST (Create Category record
)
- `/v1/categories/delete-multiple` — POST (Delete multiple Categories by their IDs
)
- `/v1/categories/{id}` — DELETE (Remove specified Category record
), GET (Get specified Category object
), PUT (Update specified Category object
)
- `/v1/categories/{id}/history` — GET (Get specified Category history object
), POST (Add specified Category history object notes
)

## check-in

- `/v3/check-in` — GET (Get Client Check-In settings
), PUT (Update Client Check-In object
)
- `/v3/check-in/history` — GET (Get Client Check-In history object
), POST (Add a Note to Client Check-In History
)

## classic-ldap

- `/v1/classic-ldap/{id}` — GET (Get mappings for OnPrem Ldap configuration with given id.)

## cloud-azure

- `/v1/cloud-azure` — POST (Create Azure Cloud Identity Provider configuration)
- `/v1/cloud-azure/defaults/mappings` — GET (Get default mappings)
- `/v1/cloud-azure/defaults/server-configuration` — GET (Get default server configuration)
- `/v1/cloud-azure/{id}` — DELETE (Delete Cloud Identity Provider configuration.), GET (Get Azure Cloud Identity Provider configuration with given ID.), PUT (Update Azure Cloud Identity Provider configuration)

## cloud-distribution-point

- `/v1/cloud-distribution-point` — DELETE (Delete cloud distribution point.), GET (Get the cloud distribution point Details.
), PATCH (Update specific fields on a cloud distribution point), POST (Create cloud distribution point)
- `/v1/cloud-distribution-point/fail-upload/{id}` — POST (Marks a specific file upload as failed for the currently configured cloud distribution point.
)
- `/v1/cloud-distribution-point/files` — GET (Get the cloud distribution point Inventory files details)
- `/v1/cloud-distribution-point/history` — GET (Get cloud distribution point history details), POST (Add specified cloud distribution point history object notes)
- `/v1/cloud-distribution-point/refresh-inventory` — POST (Updates inventory data for the currently configured cloud distribution point.
)
- `/v1/cloud-distribution-point/test-connection` — GET (Get the cloud distribution point test connection details.
)
- `/v1/cloud-distribution-point/upload-capability` — GET (Finds specific information for the currently configured cloud distribution point.
)

## cloud-idp

- `/v1/cloud-idp` — GET (Get information about all Cloud Identity Providers configurations.)
- `/v1/cloud-idp/export` — POST (Export Cloud Identity Providers collection
)
- `/v1/cloud-idp/{id}` — GET (Get Cloud Identity Provider configuration with given ID.)
- `/v1/cloud-idp/{id}/history` — GET (Get Cloud Identity Provider history), POST (Add Cloud Identity Provider history note)
- `/v1/cloud-idp/{id}/test-group` — POST (Get group test search)
- `/v1/cloud-idp/{id}/test-user` — POST (Get user test search)
- `/v1/cloud-idp/{id}/test-user-membership` — POST (Get membership test search)

## cloud-information

- `/v1/cloud-information` — GET (Retrieve information related to cloud setup.
)

## cloud-ldaps

- `/v2/cloud-ldaps` — POST (Create Cloud Identity Provider configuration)
- `/v2/cloud-ldaps/defaults/{provider}/mappings` — GET (Get default mappings)
- `/v2/cloud-ldaps/defaults/{provider}/server-configuration` — GET (Get default server configuration)
- `/v2/cloud-ldaps/{id}` — DELETE (Delete Cloud Identity Provider configuration.), GET (Get Cloud Identity Provider configuration with given id.), PUT (Update Cloud Identity Provider configuration)
- `/v2/cloud-ldaps/{id}/connection/bind` — GET (Get bind connection pool statistics)
- `/v2/cloud-ldaps/{id}/connection/search` — GET (Get search connection pool statistics)
- `/v2/cloud-ldaps/{id}/connection/status` — GET (Tests the communication with the specified cloud connection
)
- `/v2/cloud-ldaps/{id}/mappings` — GET (Get mappings configurations for Cloud Identity Providers server configuration.), PUT (Update Cloud Identity Provider mappings configuration.)

## computer-extension-attributes

- `/v1/computer-extension-attributes` — GET (Retrieve Computer Extension Attributes.), POST (Create Computer Extension Attribute.)
- `/v1/computer-extension-attributes/delete-multiple` — POST (Delete multiple Computer Extension Attribute at once.)
- `/v1/computer-extension-attributes/templates` — GET (Retrieve All Computer Extension Attributes Templates.)
- `/v1/computer-extension-attributes/templates/{id}` — GET (Get specified Computer Extension Attribute Template object.)
- `/v1/computer-extension-attributes/upload` — POST (Upload Computer Extension Attribute.)
- `/v1/computer-extension-attributes/{id}` — DELETE (Remove specified Computer Extension Attribute.), GET (Get specified Computer Extension Attribute object.), PUT (Update specified Computer Extension Attribute object.)
- `/v1/computer-extension-attributes/{id}/data-dependency` — GET (Get smart group/advance search dependent objects for a specified computer extension attribute)
- `/v1/computer-extension-attributes/{id}/download` — GET (Download the specified Computer Extension Attribute.)
- `/v1/computer-extension-attributes/{id}/history` — GET (Get specified Computer Extension Attribute History object), POST (Add specified Computer Extension Attribute history object notes)

## computer-groups

- `/v1/computer-groups` — GET (Returns the list of all computer groups
)
- `/v2/computer-groups/smart-group-membership/{id}` — GET (Get the membership of a Smart Computer Group
)
- `/v2/computer-groups/smart-groups` — GET (Search for Smart Computer Groups
), POST (Create a Smart Computer Group
)
- `/v2/computer-groups/smart-groups/{id}` — DELETE (Remove specified Smart Computer Group
), GET (Get Smart Computer Group by Id
), PUT (Update a Smart Computer Group
)
- `/v2/computer-groups/static-groups` — GET (Search for Static Computer Groups
), POST (Create membership of a static computer group.
)
- `/v2/computer-groups/static-groups/{id}` — DELETE (Remove Static Computer Group by Id
), GET (Get Static Computer Group by Id
), PUT (Update membership of a static computer group.
)
- `/v3/computer-groups/smart-group-membership/{id}` — GET (Get the membership of a Smart Computer Group
)
- `/v3/computer-groups/smart-groups` — GET (Search for Smart Computer Groups
), POST (Create a Smart Computer Group
)
- `/v3/computer-groups/smart-groups/{id}` — DELETE (Remove specified Smart Computer Group
), GET (Get Smart Computer Group by Id
), PUT (Update a Smart Computer Group
)
- `/v3/computer-groups/static-groups` — GET (Search for Static Computer Groups
), POST (Create membership of a static computer group.
)
- `/v3/computer-groups/static-groups/{id}` — DELETE (Remove Static Computer Group by Id
), GET (Get Static Computer Group by Id
), PUT (Update membership of a static computer group.
)

## computer-inventory

- `/v1/computer-inventory/{id}/erase` — POST (Erase a computer
)
- `/v1/computer-inventory/{id}/remove-mdm-profile` — POST (Remove a computer's MDM profile
)

## computer-inventory-collection-settings

- `/v1/computer-inventory-collection-settings` — GET (Returns computer inventory settings), PATCH (Update computer inventory settings)
- `/v1/computer-inventory-collection-settings/custom-path` — POST (Create Computer Inventory Collection Settings Custom Path)
- `/v1/computer-inventory-collection-settings/custom-path/{id}` — DELETE (Delete Custom Path from Computer Inventory Collection Settings)
- `/v2/computer-inventory-collection-settings` — GET (Returns computer inventory settings), PATCH (Update computer inventory settings)
- `/v2/computer-inventory-collection-settings/custom-path` — POST (Create Computer Inventory Collection Settings Custom Path)
- `/v2/computer-inventory-collection-settings/custom-path/{id}` — DELETE (Delete Custom Path from Computer Inventory Collection Settings)

## computer-prestages

- `/v2/computer-prestages/scope` — GET (Get all device Scope for all Computer Prestages
)
- `/v2/computer-prestages/{id}/scope` — GET (Get device Scope for a specific Computer Prestage
), POST (Add device Scope for a specific Computer Prestage
), PUT (Replace device Scope for a specific Computer Prestage
)
- `/v2/computer-prestages/{id}/scope/delete-multiple` — POST (Remove device Scope for a specific Computer Prestage
)
- `/v3/computer-prestages` — GET (Get sorted and paged Computer Prestages
), POST (Create a Computer Prestage
)
- `/v3/computer-prestages/{id}` — DELETE (Delete a Computer Prestage with the supplied id
), GET (Retrieve a Computer Prestage with the supplied id
), PUT (Update a Computer Prestage
)

## computers

- `/v1/computers/{id}/recalculate-smart-groups` — POST (Recalculate a smart group for the given id
)

## computers-inventory

- `/v1/computers-inventory` — GET (Return paginated Computer Inventory records), POST (Create Computer Inventory record)
- `/v1/computers-inventory/filevault` — GET (Return paginated FileVault information for all computers)
- `/v1/computers-inventory/{id}` — DELETE (Remove specified Computer record), GET (Return General section of a Computer)
- `/v1/computers-inventory/{id}/attachments` — POST (Upload attachment and assign to computer)
- `/v1/computers-inventory/{id}/attachments/{attachmentId}` — DELETE (Remove attachment), GET (Download attachment file)
- `/v1/computers-inventory/{id}/filevault` — GET (Return FileVault information for a specific computer)
- `/v1/computers-inventory/{id}/view-device-lock-pin` — GET (Return a computer's Device Lock PIN)
- `/v1/computers-inventory/{id}/view-recovery-lock-password` — GET (Return a Computers Recovery Lock Password)
- `/v2/computers-inventory` — GET (Return paginated Computer Inventory records), POST (Create Computer Inventory record)
- `/v2/computers-inventory/filevault` — GET (Return paginated FileVault information for all computers)
- `/v2/computers-inventory/{id}` — DELETE (Remove specified Computer record), GET (Return General section of a Computer)
- `/v2/computers-inventory/{id}/attachments` — POST (Upload attachment and assign to computer)
- `/v2/computers-inventory/{id}/attachments/{attachmentId}` — DELETE (Remove attachment), GET (Download attachment file)
- `/v2/computers-inventory/{id}/filevault` — GET (Return FileVault information for a specific computer)
- `/v2/computers-inventory/{id}/view-device-lock-pin` — GET (Return a computer's Device Lock PIN)
- `/v2/computers-inventory/{id}/view-recovery-lock-password` — GET (Return a Computers Recovery Lock Password)
- `/v3/computers-inventory` — GET (Return paginated Computer Inventory records), POST (Create Computer Inventory record)
- `/v3/computers-inventory/filevault` — GET (Return paginated FileVault information for all computers)
- `/v3/computers-inventory/{id}` — DELETE (Remove specified Computer record), GET (Return General section of a Computer)
- `/v3/computers-inventory/{id}/attachments` — POST (Upload attachment and assign to computer)
- `/v3/computers-inventory/{id}/attachments/{attachmentId}` — DELETE (Remove attachment), GET (Download attachment file)
- `/v3/computers-inventory/{id}/filevault` — GET (Return FileVault information for a specific computer)
- `/v3/computers-inventory/{id}/view-device-lock-pin` — GET (Return a computer's Device Lock PIN)
- `/v3/computers-inventory/{id}/view-recovery-lock-password` — GET (Return a Computers Recovery Lock Password)
- `/v4/computers-inventory` — GET (Return paginated Computer Inventory records), POST (Create Computer Inventory record)
- `/v4/computers-inventory/filevault` — GET (Return paginated FileVault information for all computers)
- `/v4/computers-inventory/{id}` — DELETE (Remove specified Computer record), GET (Return General section of a Computer)
- `/v4/computers-inventory/{id}/attachments` — POST (Upload attachment and assign to computer)
- `/v4/computers-inventory/{id}/attachments/{attachmentId}` — DELETE (Remove attachment), GET (Download attachment file)
- `/v4/computers-inventory/{id}/erase` — POST (Erase a computer)
- `/v4/computers-inventory/{id}/filevault` — GET (Return FileVault information for a specific computer)
- `/v4/computers-inventory/{id}/remove-mdm-profile` — POST (Remove a computer's MDM profile)
- `/v4/computers-inventory/{id}/view-device-lock-pin` — GET (Return a computer's Device Lock PIN)
- `/v4/computers-inventory/{id}/view-recovery-lock-password` — GET (Return a Computers Recovery Lock Password)

## computers-inventory-detail

- `/v1/computers-inventory-detail/{id}` — GET (Return all sections of a computer), PATCH (Update specific fields on a computer)
- `/v2/computers-inventory-detail/{id}` — GET (Return all sections of a computer), PATCH (Update specific fields on a computer)
- `/v3/computers-inventory-detail/{id}` — GET (Return all sections of a computer), PATCH (Update specific fields on a computer)
- `/v4/computers-inventory-detail/{id}` — GET (Return all sections of a computer), PATCH (Update specific fields on a computer)

## conditional-access

- `/v1/conditional-access/device-compliance-information/computer/{deviceId}` — GET (Get compliance information for a single computer device)
- `/v1/conditional-access/device-compliance-information/mobile/{deviceId}` — GET (Get compliance information for a single mobile device)
- `/v1/conditional-access/device-compliance/feature-toggle` — GET (Retrieves Status of the Feature Toggle)

## csa

- `/v1/csa/tenant-id` — GET (Returns the CSA tenant ID.)
- `/v1/csa/token` — DELETE (Delete the CSA token exchange - This will disable Jamf Pro's ability to authenticate with cloud-hosted services
), GET (Get details regarding the CSA token exchange
)

## dashboard

- `/v1/dashboard` — GET (Get all the dashboard setup information
)
- `/v1/dashboard/toggle` — POST (Add or remove an object to the Jamf Pro dashboard
)

## ddm

- `/v1/ddm/{clientManagementId}/status-items` — GET (Retrieve the Status Items from the latest Status Report for a device)
- `/v1/ddm/{clientManagementId}/status-items/{key}` — GET (Retrieve a Status Item from the latest Status Report for a device)
- `/v1/ddm/{clientManagementId}/sync` — POST (Force a device DDM sync)

## departments

- `/v1/departments` — GET (Search for Departments
), POST (Create department record
)
- `/v1/departments/delete-multiple` — POST (Deletes all departments by ids passed in body
)
- `/v1/departments/{id}` — DELETE (Remove specified department record
), GET (Get specified Department object
), PUT (Update specified department object
)
- `/v1/departments/{id}/history` — GET (Get specified Department history object
), POST (Add specified Department history object notes
)

## deploy-package

- `/v1/deploy-package` — POST (Deploy packages using MDM)

## device-communication-settings

- `/v1/device-communication-settings` — GET (Retrieves all settings for device communication
), PUT (Update device communication settings
)
- `/v1/device-communication-settings/history` — GET (Get Device Communication settings history
), POST (Add Device Communication Settings history notes
)

## device-enrollments

- `/v1/device-enrollments` — GET (Read all sorted and paged Device Enrollment instances
)
- `/v1/device-enrollments/public-key` — GET (Retrieve the Jamf Pro Device Enrollment public key
)
- `/v1/device-enrollments/syncs` — GET (Get all instance sync states for all Device Enrollment Instances
)
- `/v1/device-enrollments/upload-token` — POST (Create a Device Enrollment Instance with the supplied Token
)
- `/v1/device-enrollments/{id}` — DELETE (Delete a Device Enrollment Instance with the supplied id
), GET (Retrieve a Device Enrollment Instance with the supplied id
), PUT (Update a Device Enrollment Instance with the supplied id
)
- `/v1/device-enrollments/{id}/devices` — GET (Retrieve a list of Devices assigned to the supplied id
)
- `/v1/device-enrollments/{id}/disown` — POST (Disown devices from the given Device Enrollment Instance
)
- `/v1/device-enrollments/{id}/history` — GET (Get sorted and paged Device Enrollment history objects
), POST (Add Device Enrollment history object notes
)
- `/v1/device-enrollments/{id}/syncs` — GET (Get all instance sync states for a single Device Enrollment Instance
)
- `/v1/device-enrollments/{id}/syncs/latest` — GET (Get the latest sync state for a single Device Enrollment Instance
)
- `/v1/device-enrollments/{id}/upload-token` — PUT (Update a Device Enrollment Instance with the supplied Token
)

## devices

- `/devices/extensionAttributes` — GET (Get Mobile Device Extension Attribute values placed in select paramter
)
- `/v1/devices/{id}/groups` — GET (Return a list of groups for a device
)

## distribution-points

- `/v1/distribution-points` — GET (Finds all Distribution Points), POST (Create distribution point)
- `/v1/distribution-points/delete-multiple` — POST (Delete multiple distribution points at once)
- `/v1/distribution-points/{id}` — DELETE (Remove specified distribution point
), GET (Get specified distribution point
), PATCH (Update specified distribution point object
), PUT (Update specified distribution point object
)
- `/v1/distribution-points/{id}/history` — GET (Get specified distribution point History object
), POST (Add specified distribution point History object notes
)

## dock-items

- `/v1/dock-items` — POST (Create a DockItem
)
- `/v1/dock-items/{id}` — DELETE (Delete a DockItem at the specified id
), GET (Retrieve a full dockItem object
), PUT (Replace the dockItem at the id with the supplied information
)

## dss-declarations

- `/v1/dss-declarations/{declarationId}` — GET (Retrieve an existing declaration)

## ebooks

- `/v1/ebooks` — GET (Get Ebook object
)
- `/v1/ebooks/{id}` — GET (Get specified Ebook object
)
- `/v1/ebooks/{id}/scope` — GET (Get specified scope of Ebook object
)

## enrollment

- `/v2/enrollment/history` — GET (Get sorted and paged Enrollment history object
), POST (Add Enrollment history object notes
)
- `/v2/enrollment/history/export` — POST (Export enrollment history collection
)
- `/v3/enrollment/access-groups` — GET (Retrieve the configured LDAP groups configured for User-Initiated Enrollment.
), POST (Add the configured LDAP group for User-Initiated Enrollment.
)
- `/v3/enrollment/access-groups/{id}` — DELETE (Delete an LDAP group's access to user initiated Enrollment.
), GET (Retrieve the configured LDAP groups configured for User-Initiated Enrollment
), PUT (Modify the configured LDAP groups configured for User-Initiated Enrollment. Only exiting Access Groups can be updated.
)
- `/v3/enrollment/filtered-language-codes` — GET (Retrieve the list of languages and corresponding ISO 639-1 Codes but only those not already added to Enrollment
)
- `/v3/enrollment/language-codes` — GET (Retrieve the list of languages and corresponding ISO 639-1 Codes
)
- `/v3/enrollment/languages` — GET (Get an array of the language codes that have Enrollment messaging
)
- `/v3/enrollment/languages/delete-multiple` — POST (Delete multiple configured languages from User-Initiated Enrollment settings
)
- `/v3/enrollment/languages/{languageId}` — DELETE (Delete the Enrollment messaging for a language
), GET (Retrieve the Enrollment messaging for a language
), PUT (Edit Enrollment messaging for a language
)
- `/v4/enrollment` — GET (Get Enrollment object and Re-enrollment settings
), PUT (Update Enrollment object
)
- `/v4/enrollment/access-management` — GET (Get Access Management settings), POST (Configure Access Management settings
)

## enrollment-customization

- `/v1/enrollment-customization/parse-markdown` — POST (Parse the given string as markdown text and return Html output
)
- `/v1/enrollment-customization/{id}/all` — GET (Get all Panels for single Enrollment Customization
)
- `/v1/enrollment-customization/{id}/all/{panel-id}` — DELETE (Delete a single Panel from an Enrollment Customization
), GET (Get a single Panel for a single Enrollment Customization
)
- `/v1/enrollment-customization/{id}/ldap` — POST (Create an LDAP Panel for a single Enrollment Customization
)
- `/v1/enrollment-customization/{id}/ldap/{panel-id}` — DELETE (Delete an LDAP single panel from an Enrollment Customization
), GET (Get a single LDAP panel for a single Enrollment Customization
), PUT (Update a single LDAP Panel for a single Enrollment Customization
)
- `/v1/enrollment-customization/{id}/sso` — POST (Create an SSO Panel for a single Enrollment Customization
)
- `/v1/enrollment-customization/{id}/sso/{panel-id}` — DELETE (Delete a single SSO Panel from an Enrollment Customization
), GET (Get a single SSO Panel for a single Enrollment Customization
), PUT (Update a single SSO Panel for a single Enrollment Customization
)
- `/v1/enrollment-customization/{id}/text` — POST (Create a Text Panel for a single Enrollment Customization
)
- `/v1/enrollment-customization/{id}/text/{panel-id}` — DELETE (Delete a Text single Panel from an Enrollment Customization
), GET (Get a single Text Panel for a single Enrollment Customization
), PUT (Update a single Text Panel for a single Enrollment Customization
)
- `/v1/enrollment-customization/{id}/text/{panel-id}/markdown` — GET (Get the markdown output of a single Text Panel for a single Enrollment
)

## enrollment-customizations

- `/v2/enrollment-customizations` — GET (Retrieve sorted and paged Enrollment Customizations
), POST (Create an Enrollment Customization
)
- `/v2/enrollment-customizations/images` — POST (Upload an image)
- `/v2/enrollment-customizations/images/{id}` — GET (Download an enrollment customization image
)
- `/v2/enrollment-customizations/{id}` — DELETE (Delete an Enrollment Customization with the supplied id
), GET (Retrieve an Enrollment Customization with the supplied id
), PUT (Update an Enrollment Customization
)
- `/v2/enrollment-customizations/{id}/history` — GET (Get sorted and paged Enrollment Customization history objects
), POST (Add Enrollment Customization history object notes
)
- `/v2/enrollment-customizations/{id}/prestages` — GET (Retrieve the list of Prestages using this Enrollment Customization
)

## environment-type

- `/v2/environment-type` — GET (Get the cloud services environment type
)

## groups

- `/v1/groups` — GET (Returns group information for all Mobile Device and Computer groups)
- `/v1/groups/{id}` — DELETE (Delete a group by platform UUID), GET (Returns group information for the given platform UUID), PATCH (Update a group by platform UUID)
- `/v2/groups` — GET (Returns group information for all Mobile Device and Computer groups)
- `/v2/groups/{id}` — DELETE (Delete a group by platform UUID), GET (Returns group information for the given platform UUID), PATCH (Update a group by platform UUID)

## gsx-connection

- `/v1/gsx-connection` — GET (Finds the Jamf Pro GSX Connection information
), PATCH (Updates Jamf Pro GSX Connection information
), PUT (Updates Jamf Pro GSX Connection information
)
- `/v1/gsx-connection/history` — GET (Get specified GSX Connection History object
), POST (Add specified GSX Connection history object notes
)
- `/v1/gsx-connection/test` — POST (Test functionality of an GSX Connection)

## health-check

- `/v1/health-check` — GET (Get Jamf Pro API status)

## health-status

- `/v1/health-status` — GET (Retrieve request acceptance ratios for this Jamf Pro node)

## icon

- `/v1/icon` — POST (Upload an icon
)
- `/v1/icon/download/{id}` — GET (Download a self service icon
)
- `/v1/icon/{id}` — GET (Get an icon
)

## impact-alert-notification-settings

- `/v1/impact-alert-notification-settings` — GET (Get Impact Alert Notification Settings), PUT (Update Impact Alert Notification Settings)

## inventory-information

- `/v1/inventory-information` — GET (Get statistics about managed/unmanaged devices and computers in the inventory
)

## inventory-preload

- `/inventory-preload` — DELETE (Delete all Inventory Preload records
), GET (Return all Inventory Preload records
), POST (Create a new Inventory Preload record using JSON or CSV
)
- `/inventory-preload/csv-template` — GET (Get the Inventory Preload CSV template
)
- `/inventory-preload/history` — GET (Get Inventory Preload history entries
)
- `/inventory-preload/history/notes` — POST (Add Inventory Preload history object notes
)
- `/inventory-preload/validate-csv` — POST (Validate a given CSV file
)
- `/inventory-preload/{id}` — DELETE (Delete an Inventory Preload record
), GET (Get an Inventory Preload record
), PUT (Update an Inventory Preload record
)
- `/v1/inventory-preload` — DELETE (Delete all Inventory Preload records
), GET (Return all Inventory Preload records
), POST (Create a new Inventory Preload record using JSON or CSV
)
- `/v1/inventory-preload/csv-template` — GET (Retrieve the Inventory Preload CSV template
)
- `/v1/inventory-preload/history` — GET (Get Inventory Preload history entries
), POST (Add Inventory Preload history object notes
)
- `/v1/inventory-preload/validate-csv` — POST (Validate a given CSV file
)
- `/v1/inventory-preload/{id}` — DELETE (Delete an Inventory Preload record
), GET (Get an Inventory Preload record
), PUT (Update an Inventory Preload record
)
- `/v2/inventory-preload/csv` — GET (Download all Inventory Preload records), POST (Create one or more new Inventory Preload records using CSV
)
- `/v2/inventory-preload/csv-template` — GET (Download the Inventory Preload CSV template)
- `/v2/inventory-preload/csv-validate` — POST (Validate a given CSV file
)
- `/v2/inventory-preload/ea-columns` — GET (Retrieve a list of extension attribute columns
)
- `/v2/inventory-preload/export` — POST (Export a collection of inventory preload records
)
- `/v2/inventory-preload/history` — GET (Get Inventory Preload history entries
), POST (Add Inventory Preload history object notes)
- `/v2/inventory-preload/records` — GET (Return all Inventory Preload records), POST (Create a new Inventory Preload record using JSON)
- `/v2/inventory-preload/records/delete-all` — POST (Delete all Inventory Preload records
)
- `/v2/inventory-preload/records/{id}` — DELETE (Delete an Inventory Preload record
), GET (Get an Inventory Preload record), PUT (Update an Inventory Preload record)

## jamf-connect

- `/v1/jamf-connect` — GET (Get the Jamf Connect settings that you have access to see
)
- `/v1/jamf-connect/config-profiles` — GET (Search for config profiles linked to Jamf Connect
)
- `/v1/jamf-connect/config-profiles/{id}` — PUT (Update the way the Jamf Connect app gets updated on computers within scope of the associated configuration profile.
)
- `/v1/jamf-connect/deployments/{id}/tasks` — GET (Search for deployment tasks for a config profile linked to Jamf Connect
)
- `/v1/jamf-connect/deployments/{id}/tasks/retry` — POST (Request a retry of Connect install tasks
)
- `/v1/jamf-connect/history` — GET (Get Jamf Connect history
), POST (Add Jamf Connect history notes
)

## jamf-management-framework

- `/v1/jamf-management-framework/redeploy/{id}` — POST (Redeploy Jamf Management Framework
)

## jamf-package

- `/v1/jamf-package` — GET (Get the packages for a given Jamf application
)
- `/v2/jamf-package` — GET (Get the packages for a given Jamf application
)

## jamf-pro-information

- `/v2/jamf-pro-information` — GET (Get basic information about the Jamf Pro Server
)

## jamf-pro-server-url

- `/v1/jamf-pro-server-url` — GET (Get Jamf Pro Server URL settings
), PUT (Update Jamf Pro Server URL settings
)
- `/v1/jamf-pro-server-url/history` — GET (Get Jamf Pro Server URL settings history
), POST (Add Jamf Pro Server URL settings history notes
)

## jamf-pro-version

- `/v1/jamf-pro-version` — GET (Return information about the Jamf Pro including the current version
)

## jamf-protect

- `/v1/jamf-protect` — DELETE (Delete Jamf Protect API registration.), GET (Jamf Protect integration settings), PUT (Jamf Protect integration settings)
- `/v1/jamf-protect/deployments/{id}/tasks` — GET (Search for deployment tasks for a config profile linked to Jamf Protect
)
- `/v1/jamf-protect/deployments/{id}/tasks/retry` — POST (Request a retry of Protect install tasks
)
- `/v1/jamf-protect/history` — GET (Get Jamf Protect history
), POST (Add Jamf Protect history notes
)
- `/v1/jamf-protect/plans` — GET (Get all of the previously synced Jamf Protect Plans with information about their associated configuration profile)
- `/v1/jamf-protect/plans/sync` — POST (Sync Plans with Jamf Protect)
- `/v1/jamf-protect/register` — POST (Register a Jamf Protect API configuration with Jamf Pro)

## jamf-remote-assist

- `/v1/jamf-remote-assist/session` — GET (Gets session history items.
)
- `/v1/jamf-remote-assist/session/{id}` — GET (Gets single session history item.
)
- `/v2/jamf-remote-assist/session` — GET (Gets session history items.
)
- `/v2/jamf-remote-assist/session/export` — POST (Export Jamf Remote Assist sessions history
)
- `/v2/jamf-remote-assist/session/{id}` — GET (Gets single session history item.
)

## jcds

- `/v1/jcds/files` — GET (Retrieve a list of files and file metadata from the Jamf Cloud Distribution Service), POST (Initiate an upload to the Jamf Cloud Distribution Service)
- `/v1/jcds/files/{fileName}` — DELETE (Delete a file from the Jamf Cloud Distribution Service), GET (Retrieve a download URL for a specific file from the Jamf Cloud Distribution Service)
- `/v1/jcds/refresh-inventory` — POST (Refreshes the inventory and status of uploads in Jamf Pro. This will update the 
status of uploads in the Jamf Pro database and allow the uploads to be deployed.
)
- `/v1/jcds/renew-credentials` — POST (Renew credentials for an upload to the Jamf Cloud Distribution Service)

## last-login

- `/v1/last-login` — GET (Get the date of the last login event)

## ldap

- `/ldap/groups` — GET (Retrieve the configured access groups that contain the text in the search param
)
- `/ldap/servers` — GET (Retrieve all Servers including LDAP and Cloud Identity Providers.
)
- `/v1/ldap/groups` — GET (Retrieve the configured access groups that contain the text in the search param
)
- `/v1/ldap/ldap-servers` — GET (Retrieve all LDAP Servers.
)
- `/v1/ldap/servers` — GET (Retrieve all Servers including LDAP and Cloud Identity Providers.
)

## ldap-keystore

- `/v1/ldap-keystore/verify` — POST (Validate keystore for Cloud Identity Provider secure connection)

## local-admin-password

- `/v2/local-admin-password/pending-rotations` — GET (Get a list of the current devices and usernames with pending LAPS rotations)
- `/v2/local-admin-password/settings` — GET (Get the current LAPS settings.), PUT (Update settings for LAPS.)
- `/v2/local-admin-password/{clientManagementId}/account/{username}/audit` — GET (Get LAPS password viewed history.)
- `/v2/local-admin-password/{clientManagementId}/account/{username}/history` — GET (Get LAPS historical records for target device and username.)
- `/v2/local-admin-password/{clientManagementId}/account/{username}/password` — GET (Get current LAPS password for specified username on a client.)
- `/v2/local-admin-password/{clientManagementId}/account/{username}/{guid}/audit` — GET (Get LAPS password viewed history.)
- `/v2/local-admin-password/{clientManagementId}/account/{username}/{guid}/history` — GET (Get LAPS historical records for target device and user guid.)
- `/v2/local-admin-password/{clientManagementId}/account/{username}/{guid}/password` — GET (Get current LAPS password for specified user guid on a client.)
- `/v2/local-admin-password/{clientManagementId}/accounts` — GET (Get the LAPS capable admin accounts for a device.)
- `/v2/local-admin-password/{clientManagementId}/history` — GET (Get LAPS password viewed history, and rotation history.)
- `/v2/local-admin-password/{clientManagementId}/set-password` — PUT (Set the LAPS password for a device.)

## locales

- `/v1/locales` — GET (Return locales that can be used in other features
)

## log-flushing

- `/v1/log-flushing` — GET (Get log flushing settings)
- `/v1/log-flushing/task` — GET (Get log flushing tasks), POST (Queue a log flushing task)
- `/v1/log-flushing/task/{id}` — DELETE (Cancels a log flushing task), GET (Get log flushing task)

## login-customization

- `/v1/login-customization` — GET (Get current login disclaimer settings), PUT (Update current login disclaimer settings.)

## m2m

- `/v1/m2m/tenant-id` — GET (Returns the M2M-sourced tenant ID.)

## macos-managed-software-updates

- `/v1/macos-managed-software-updates/available-updates` — GET (Retrieve available MacOs Managed Software Updates)
- `/v1/macos-managed-software-updates/send-updates` — POST (Send MacOs Managed Software Updates)

## managed-software-updates

- `/v1/managed-software-updates/available-updates` — GET (Retrieve available macOS and iOS Managed Software Updates)
- `/v1/managed-software-updates/plans` — GET (Retrieve Managed Software Update Plans), POST (Create a Managed Software Update Plan)
- `/v1/managed-software-updates/plans/feature-toggle` — GET (Retrieve current value of the Feature Toggle), PUT (Updates Feature Toggle Value)
- `/v1/managed-software-updates/plans/feature-toggle/abandon` — POST (Force stops any ongoing or stalled feature-toggle processes)
- `/v1/managed-software-updates/plans/feature-toggle/status` — GET (Retrieves background status of the Feature Toggle)
- `/v1/managed-software-updates/plans/group` — POST (Create Managed Software Update Plans for a Group)
- `/v1/managed-software-updates/plans/group/{id}` — GET (Retrieve Managed Software Update Plans for a Group)
- `/v1/managed-software-updates/plans/{id}` — GET (Retrieve a Managed Software Update Plan)
- `/v1/managed-software-updates/plans/{id}/declarations` — GET (Retrieve all Declarations associated with a Managed Software Update Plan)
- `/v1/managed-software-updates/plans/{id}/events` — GET (Retrieve a Managed Software Update Plan Event Store)
- `/v1/managed-software-updates/update-statuses` — GET (Retrieve Managed Software Update Statuses)
- `/v1/managed-software-updates/update-statuses/computer-groups/{id}` — GET (Retrieve Managed Software Update Statuses for Computer Groups)
- `/v1/managed-software-updates/update-statuses/computers/{id}` — GET (Retrieve Managed Software Update Statuses for Computers)
- `/v1/managed-software-updates/update-statuses/mobile-device-groups/{id}` — GET (Retrieve Managed Software Update Statuses for Mobile Device Groups)
- `/v1/managed-software-updates/update-statuses/mobile-devices/{id}` — GET (Retrieve Managed Software Update Statuses for Mobile Devices)

## mdm

- `/v1/mdm/commands` — GET (Get information about mdm commands made by Jamf Pro.)
- `/v1/mdm/renew-profile` — POST (Renew MDM Profile
)
- `/v2/mdm/blank-push` — POST (Send blank push notifications to a list of client management IDs.)
- `/v2/mdm/commands` — GET (Get information about mdm commands made by Jamf Pro.
), POST (Post a command for creation and queuing
)

## mdm-renewal

- `/v1/mdm-renewal/device-common-details` — PATCH (Update device common details (partial update)
)
- `/v1/mdm-renewal/device-common-details/{clientManagementId}` — GET (Get device common details for a client management ID
)
- `/v1/mdm-renewal/renewal-strategies/{clientManagementId}` — DELETE (Delete MDM renewal strategies for a client management ID
), GET (Get MDM renewal errors and strategies for a client management ID
)

## mobile-device-apps

- `/v1/mobile-device-apps/reinstall-app-config` — POST (Reinstall App Config for Managed iOS Apps
)

## mobile-device-enrollment-profile

- `/v1/mobile-device-enrollment-profile/{id}/download-profile` — GET (Retrieve the MDM Enrollment Profile
)

## mobile-device-extension-attributes

- `/v1/mobile-device-extension-attributes` — GET (Retrieve Mobile Device Extension Attributes.), POST (Create Mobile Device Extension Attribute.)
- `/v1/mobile-device-extension-attributes/{id}` — DELETE (Delete a Mobile Device Extension Attribute by ID.), GET (Get specified Mobile Device Extension Attribute object.), PUT (Update specified Mobile Device Extension Attribute object.)
- `/v1/mobile-device-extension-attributes/{id}/data-dependency` — GET (Get smart group dependent object for a specified mobile device extension attribute)
- `/v1/mobile-device-extension-attributes/{id}/history` — GET (Get specified Mobile Device Extension Attribute History object), POST (Add specified Mobile Device Extension Attribute history object notes)

## mobile-device-groups

- `/v1/mobile-device-groups` — GET (Return the list of all Mobile Device Groups
)
- `/v1/mobile-device-groups/smart-group-membership/{id}` — GET (Get Smart Group Membership by Id
)
- `/v1/mobile-device-groups/smart-groups` — GET (Get Smart Groups
), POST (Create a smart group
)
- `/v1/mobile-device-groups/smart-groups/{id}` — DELETE (Remove Smart Group by Id
), GET (Get Smart Group by Id
), PUT (Update a smart group
)
- `/v1/mobile-device-groups/static-group-membership/{id}` — GET (Get Static Group Membership by Id
)
- `/v1/mobile-device-groups/static-groups` — GET (Get Static Groups
), POST (Create membership of a static group
)
- `/v1/mobile-device-groups/static-groups/{id}` — DELETE (Remove Static Group by Id
), GET (Get Static Group by Id
), PATCH (Update membership of a static group
)
- `/v1/mobile-device-groups/{id}/erase` — POST (Erase all devices in the group
)
- `/v2/mobile-device-groups` — GET (Return the list of all Mobile Device Groups
)
- `/v2/mobile-device-groups/smart-group-membership/{id}` — GET (Get Smart Group Membership by Id
)
- `/v2/mobile-device-groups/smart-groups` — GET (Get Smart Groups
), POST (Create a smart group
)
- `/v2/mobile-device-groups/smart-groups/{id}` — DELETE (Remove Smart Group by Id
), GET (Get Smart Group by Id
), PUT (Update a smart group
)
- `/v2/mobile-device-groups/static-group-membership/{id}` — GET (Get Static Group Membership by Id
)
- `/v2/mobile-device-groups/static-groups` — GET (Get Static Groups
), POST (Create a static group
)
- `/v2/mobile-device-groups/static-groups/{id}` — DELETE (Remove Static Group by Id
), GET (Get Static Group by Id
), PATCH (Update a static group
)
- `/v2/mobile-device-groups/{id}/erase` — POST (Erase all devices in the group
)

## mobile-device-prestages

- `/v2/mobile-device-prestages` — GET (Get sorted and paged Mobile Device Prestages
), POST (Create a Mobile Device Prestage
)
- `/v2/mobile-device-prestages/scope` — GET (Get all Device Scope for all Mobile Device Prestages
)
- `/v2/mobile-device-prestages/syncs` — GET (Get all Prestage sync States for all prestages
)
- `/v2/mobile-device-prestages/{id}` — DELETE (Delete a Mobile Device Prestage with the supplied id
), GET (Retrieve a Mobile Device Prestage with the supplied id
), PUT (Update a Mobile Device Prestage
)
- `/v2/mobile-device-prestages/{id}/attachments` — GET (Get attachments for a Mobile Device Prestage
), POST (Add an attachment to a Mobile Device Prestage
)
- `/v2/mobile-device-prestages/{id}/attachments/delete-multiple` — POST (Remove an attachment for a Mobile Device Prestage
)
- `/v2/mobile-device-prestages/{id}/history` — GET (Get sorted and paged Mobile Device Prestage history objects
), POST (Add Mobile Device Prestage history object notes
)
- `/v2/mobile-device-prestages/{id}/scope` — GET (Get Device Scope for a specific Mobile Device Prestage
), POST (Add Device Scope for a specific Mobile Device Prestage
), PUT (Replace Device Scope for a specific Mobile Device Prestage
)
- `/v2/mobile-device-prestages/{id}/scope/delete-multiple` — POST (Remove Device Scope for a specific Mobile Device Prestage
)
- `/v2/mobile-device-prestages/{id}/syncs` — GET (Get all prestage sync states for a single prestage
)
- `/v2/mobile-device-prestages/{id}/syncs/latest` — GET (Get the latest Sync State for a single Prestage
)
- `/v3/mobile-device-prestages` — GET (Get sorted and paged Mobile Device Prestages
), POST (Create a Mobile Device Prestage
)
- `/v3/mobile-device-prestages/{id}` — DELETE (Delete a Mobile Device Prestage with the supplied id
), GET (Retrieve a Mobile Device Prestage with the supplied id
), PUT (Update a Mobile Device Prestage
)
- `/v3/mobile-device-prestages/{id}/attachments` — GET (Get attachments for a Mobile Device Prestage
), POST (Add an attachment to a Mobile Device Prestage
)
- `/v3/mobile-device-prestages/{id}/attachments/delete-multiple` — POST (Remove an attachment for a Mobile Device Prestage
)
- `/v3/mobile-device-prestages/{id}/history` — GET (Get sorted and paged Mobile Device Prestage history objects
), POST (Add Mobile Device Prestage history object notes
)

## mobile-devices

- `/v1/mobile-devices/{id}/recalculate-smart-groups` — POST (Recalculate all smart groups for the given device id and then return count of smart groups that device fall into
)
- `/v2/mobile-devices` — GET (Get Mobile Device objects
)
- `/v2/mobile-devices/detail` — GET (Return paginated Mobile Device Inventory records)
- `/v2/mobile-devices/{id}` — GET (Get Mobile Device
), PATCH (Update fields on a mobile device that are allowed to be modified by users
)
- `/v2/mobile-devices/{id}/detail` — GET (Get Mobile Device
)
- `/v2/mobile-devices/{id}/erase` — POST (Erase a Mobile Device
)
- `/v2/mobile-devices/{id}/paired-devices` — GET (Return paginated Mobile Device Inventory records of all paired devices for the device
)
- `/v2/mobile-devices/{id}/unmanage` — POST (Unmanage a Mobile Device
)

## notifications

- `/v1/notifications` — GET (Get Notifications for user and site
)
- `/v1/notifications/{type}/{id}` — DELETE (Delete Notifications
)

## oauth

- `/v1/oauth/token` — POST (Obtain an access token using an API Client)

## oauth2

- `/v1/oauth2/session-tokens` — GET (Retrieve the access token and user information for the current session.
)

## oidc

- `/v1/oidc/direct-idp-login-url` — GET (Retrieve the URL to directly login to the IdP
)
- `/v1/oidc/dispatch` — POST (Provide the url to redirect for OIDC login)
- `/v1/oidc/generate-certificate` — POST (Generate a new keystore used for signing OIDC messages
)
- `/v1/oidc/public-features` — GET (Get the public features of the OIDC configuration)
- `/v1/oidc/public-key` — GET (Get the public key of the keystore used for signing OIDC messages as a JWT
)
- `/v2/oidc/dispatch` — POST (Provide the url to redirect for OIDC login)

## onboarding

- `/v1/onboarding` — GET (Get the current onboarding settings configuration.), PUT (Update the onboarding configuration.)
- `/v1/onboarding/eligible-apps` — GET (Retrieves a list of applications that are eligible to be used in an onboarding configuration)
- `/v1/onboarding/eligible-configuration-profiles` — GET (Retrieves a list of configuration profiles that are eligible to be used in an onboarding configuration)
- `/v1/onboarding/eligible-policies` — GET (Retrieves a list of policies that are eligible to be used in an onboarding configuration)
- `/v1/onboarding/history` — GET (Get Onboarding history object
), POST (Add Onboarding history object notes
)
- `/v1/onboarding/history/export` — POST (Export history object collection in specified format for Onboarding
)

## packages

- `/v1/packages` — GET (Retrieve Packages), POST (Create package)
- `/v1/packages/delete-multiple` — POST (Delete multiple packages at once)
- `/v1/packages/export` — POST (Export Packages collection
)
- `/v1/packages/{id}` — DELETE (Remove specified package
), GET (Get specified Package object
), PUT (Update specified package object
)
- `/v1/packages/{id}/history` — GET (Get specified Package History object
), POST (Add specified Package history object notes
)
- `/v1/packages/{id}/history/export` — POST (Export history object collection in specified format for specified Packages
)
- `/v1/packages/{id}/manifest` — DELETE (Delete the manifest for a specified package
), POST (Add a manifest to a package
)
- `/v1/packages/{id}/upload` — POST (Upload package)

## parent-app

- `/v1/parent-app` — GET (Get the current Jamf Parent app settings
), PUT (Update Jamf Parent app settings
)
- `/v1/parent-app/history` — GET (Get Jamf Parent app settings history
), POST (Add Jamf Parent app settings history notes
)

## patch-management-accept-disclaimer

- `/v2/patch-management-accept-disclaimer` — POST (Accept Patch Management disclaimer
)

## patch-policies

- `/v2/patch-policies` — GET (Retrieve Patch Policies)
- `/v2/patch-policies/policy-details` — GET (Retrieve Patch Policies)
- `/v2/patch-policies/{id}/dashboard` — DELETE (Remove a patch policy from the dashboard
), GET (Return whether or not the requested patch policy is on the dashboard
), POST (Add a patch policy to the dashboard
)
- `/v2/patch-policies/{id}/logs` — GET (Retrieve Patch Policy Logs
)
- `/v2/patch-policies/{id}/logs/eligible-retry-count` — GET (Return the count of the Patch Policy Logs for the patch policy id that are eligible for a retry attempt
)
- `/v2/patch-policies/{id}/logs/retry` — POST (Send retry attempts for specific devices)
- `/v2/patch-policies/{id}/logs/retry-all` — POST (Send retry attempts for all devices)
- `/v2/patch-policies/{id}/logs/{deviceId}` — GET (Retrieves a single Patch Policy Log
)
- `/v2/patch-policies/{id}/logs/{deviceId}/details` — GET (Return attempt details for a specific log)

## patch-software-title-configurations

- `/v2/patch-software-title-configurations` — GET (Retrieve Patch Software Title Configurations), POST (Create Patch Software Title Configurations)
- `/v2/patch-software-title-configurations/{id}` — DELETE (Delete Patch Software Title Configurations with the supplied id), GET (Retrieve Patch Software Title Configurations with the supplied id), PATCH (Update Patch Software Title Configurations)
- `/v2/patch-software-title-configurations/{id}/dashboard` — DELETE (Remove a software title configuration from the dashboard
), GET (Return whether or not the requested software title configuration is on the dashboard
), POST (Add a software title configuration to the dashboard
)
- `/v2/patch-software-title-configurations/{id}/definitions` — GET (Retrieve Patch Software Title Definitions with the supplied id)
- `/v2/patch-software-title-configurations/{id}/dependencies` — GET (Retrieve list of Patch Software Title Configuration Dependencies)
- `/v2/patch-software-title-configurations/{id}/export-report` — GET (Export Patch Reporting Data)
- `/v2/patch-software-title-configurations/{id}/extension-attributes` — GET (Retrieve Software Title Extension Attributes with the supplied id)
- `/v2/patch-software-title-configurations/{id}/history` — GET (Get specified Patch Software Title Configuration history object
), POST (Add Patch Software Title Configuration history object notes
)
- `/v2/patch-software-title-configurations/{id}/patch-report` — GET (Retrieve Patch Software Title Configuration Patch Report)
- `/v2/patch-software-title-configurations/{id}/patch-summary` — GET (Return Active Patch Summary)
- `/v2/patch-software-title-configurations/{id}/patch-summary/versions` — GET (Returns patch versions)
- `/v3/patch-software-title-configurations` — GET (Retrieve Patch Software Title Configurations), POST (Create Patch Software Title Configurations)
- `/v3/patch-software-title-configurations/{id}` — DELETE (Delete Patch Software Title Configurations with the supplied id), GET (Retrieve Patch Software Title Configurations with the supplied id), PATCH (Update Patch Software Title Configurations)
- `/v3/patch-software-title-configurations/{id}/dashboard` — DELETE (Remove a software title configuration from the dashboard
), GET (Return whether or not the requested software title configuration is on the dashboard
), POST (Add a software title configuration to the dashboard
)
- `/v3/patch-software-title-configurations/{id}/definitions` — GET (Retrieve Patch Software Title Definitions with the supplied id)
- `/v3/patch-software-title-configurations/{id}/dependencies` — GET (Retrieve list of Patch Software Title Configuration Dependencies)
- `/v3/patch-software-title-configurations/{id}/export-report` — GET (Export Patch Reporting Data)
- `/v3/patch-software-title-configurations/{id}/extension-attributes` — GET (Retrieve Software Title Extension Attributes with the supplied id)
- `/v3/patch-software-title-configurations/{id}/history` — GET (Get specified Patch Software Title Configuration history object
), POST (Add Patch Software Title Configuration history object notes
)
- `/v3/patch-software-title-configurations/{id}/patch-report` — GET (Retrieve Patch Software Title Configuration Patch Report)
- `/v3/patch-software-title-configurations/{id}/patch-summary` — GET (Return Active Patch Summary)
- `/v3/patch-software-title-configurations/{id}/patch-summary/versions` — GET (Returns patch versions)

## pki

- `/v1/pki/adcs-settings` — POST (Create AD CS Settings configuration for either inbound or outbound mode
)
- `/v1/pki/adcs-settings/validate-certificate` — POST (Validate AD CS Settings server certificate
)
- `/v1/pki/adcs-settings/validate-client-certificate` — POST (Validate AD CS Settings client certificate
)
- `/v1/pki/adcs-settings/{id}` — DELETE (Delete AD CS Settings configuration by ID
), GET (Get AD CS Settings configuration for the ID value
), PATCH (Update AD CS Settings configuration
)
- `/v1/pki/adcs-settings/{id}/dependencies` — GET (Retrieve list of AD CS Settings dependencies)
- `/v1/pki/adcs-settings/{id}/history` — GET (Get specified AD CS Settings history object
), POST (Add specified AD CS Settings object note
)
- `/v1/pki/certificate-authority/active` — GET (Returns X.509 details of the active Certificate Authority (CA))
- `/v1/pki/certificate-authority/active/der` — GET (Returns X.509 of active Certificate Authority (CA) in DER format)
- `/v1/pki/certificate-authority/active/pem` — GET (Returns active Certificate Authority (CA) in PEM format)
- `/v1/pki/certificate-authority/{id}` — GET (Returns X.509 details of Certificate Authority (CA) with provided ID)
- `/v1/pki/certificate-authority/{id}/der` — GET (Returns X.509 current Certificate Authority (CA) with provided ID in DER format)
- `/v1/pki/certificate-authority/{id}/pem` — GET (Returns current Certificate Authority (CA) with provided ID in PEM format)
- `/v1/pki/digicert/trust-lifecycle-manager` — POST (Create DigiCert Trust Lifecycle Manager configuration with client authentication via client certificate.
)
- `/v1/pki/digicert/trust-lifecycle-manager/validate-client-certificate` — POST (Validate DigiCert Trust Lifecycle Manager client certificate
)
- `/v1/pki/digicert/trust-lifecycle-manager/{id}` — DELETE (Delete DigiCert Trust Lifecycle Manager configuration), GET (Retrieve DigiCert Trust Lifecycle Manager configuration), PATCH (Update DigiCert Trust Lifecycle Manager configuration
)
- `/v1/pki/digicert/trust-lifecycle-manager/{id}/connection-status` — GET (Get connection status of DigiCert Trust Lifecycle Manager for a given ID)
- `/v1/pki/digicert/trust-lifecycle-manager/{id}/dependencies` — GET (Retrieve list of DigiCert Trust Lifecycle Manager Settings dependencies)
- `/v1/pki/digicert/trust-lifecycle-manager/{id}/privilege-check` — GET (Check DigiCert account permissions for certificate deployment)
- `/v1/pki/venafi` — POST (Create a PKI configuration in Jamf Pro for Venafi
)
- `/v1/pki/venafi/{id}` — DELETE (Delete a Venafi PKI configuration from Jamf Pro
), GET (Retrieve a Venafi PKI configuration from Jamf Pro
), PATCH (Update a Venafi PKI configuration in Jamf Pro
)
- `/v1/pki/venafi/{id}/connection-status` — GET (Tests the communication between Jamf Pro and a Jamf Pro PKI Proxy Server
)
- `/v1/pki/venafi/{id}/dependent-profiles` — GET (Get configuration profile data using specified Venafi CA object
)
- `/v1/pki/venafi/{id}/history` — GET (Get specified Venafi CA history object
), POST (Add specified Venafi CA Object Note
)
- `/v1/pki/venafi/{id}/jamf-public-key` — GET (Downloads a certificate used to secure communication between Jamf Pro and a Jamf Pro PKI Proxy Server
)
- `/v1/pki/venafi/{id}/jamf-public-key/regenerate` — POST (Regenerates a certificate used to secure communication between Jamf Pro and a Jamf Pro PKI Proxy Server
)
- `/v1/pki/venafi/{id}/proxy-trust-store` — DELETE (Removes the PKI Proxy Server public key used to secure communication between Jamf Pro and a Jamf Pro PKI Proxy Server
), GET (Downloads the PKI Proxy Server public key to secure communication between Jamf Pro and a Jamf Pro PKI Proxy Server
), POST (Uploads the PKI Proxy Server public key to secure communication between Jamf Pro and a Jamf Pro PKI Proxy Server
)

## policy-properties

- `/v1/policy-properties` — GET (Get Policy Properties object
), PUT (Update Policy Properties object
)

## preview

- `/preview/computers` — GET (Return a list of Computers
)
- `/preview/remote-administration-configurations` — GET (Get information about all remote administration configurations.)
- `/preview/remote-administration-configurations/team-viewer` — POST (Create Team Viewer Remote Administration connection configuration)
- `/preview/remote-administration-configurations/team-viewer/{configurationId}/sessions` — GET (Get a paginated list of sessions
), POST (Create a new session)
- `/preview/remote-administration-configurations/team-viewer/{configurationId}/sessions/{sessionId}` — GET (Get a session by its ID
)
- `/preview/remote-administration-configurations/team-viewer/{configurationId}/sessions/{sessionId}/close` — POST (Close a session)
- `/preview/remote-administration-configurations/team-viewer/{configurationId}/sessions/{sessionId}/resend-notification` — POST (Resend nofications for a session)
- `/preview/remote-administration-configurations/team-viewer/{configurationId}/sessions/{sessionId}/status` — GET (Get a session status by its ID
)
- `/preview/remote-administration-configurations/team-viewer/{id}` — DELETE (Delete Team Viewer Remote Administration connection configuration), GET (Get Team Viewer Remote Administration connection configuration), PATCH (Update Team Viewer Remote Administration connection configuration)
- `/preview/remote-administration-configurations/team-viewer/{id}/status` — GET (Get Team Viewer Remote Administration connection status)

## reenrollment

- `/v1/reenrollment` — GET (Get Re-enrollment object
), PUT (Update the Re-enrollment object
)
- `/v1/reenrollment/history` — GET (Get Re-enrollment history object
), POST (Add specified Re-enrollment history object notes
)
- `/v1/reenrollment/history/export` — POST (Export reenrollment history collection
)

## return-to-service

- `/v1/return-to-service` — GET (Get all Return to Service Configurations
), POST (Create a Return to Service Configuration
)
- `/v1/return-to-service/{id}` — DELETE (Delete a Return To Service Configuration with the supplied id
), GET (Retrieve a Return to Service Configuration with the supplied id
), PUT (Update a Return to Service Configuration
)

## scheduler

- `/v1/scheduler/jobs` — GET (Retrieve all Jamf Pro Scheduler jobs)
- `/v1/scheduler/jobs/{jobKey}/triggers` — GET (Retrieve all triggers for a Jamf Pro Scheduler job)
- `/v1/scheduler/summary` — GET (Retrieve a summary of the Jamf Pro Scheduler)

## scripts

- `/v1/scripts` — GET (Search for sorted and paged Scripts
), POST (Create a Script
)
- `/v1/scripts/{id}` — DELETE (Delete a Script at the specified id
), GET (Retrieve a full script object
), PUT (Replace the script at the id with the supplied information
)
- `/v1/scripts/{id}/download` — GET (Download a text file of the Script contents
)
- `/v1/scripts/{id}/history` — GET (Get specified Script history object
), POST (Add specified Script history object notes
)

## self-service

- `/self-service/branding/images` — POST (Upload an image
)
- `/v1/self-service/branding/ios` — GET (Search for sorted and paged iOS branding configurations
), POST (Create a Self Service iOS branding configuration with the supplied
)
- `/v1/self-service/branding/ios/{id}` — DELETE (Delete the Self Service iOS branding configuration indicated by the provided id
), GET (Read a single Self Service iOS branding configuration indicated by the provided id
), PUT (Update a Self Service iOS branding configuration with the supplied details
)
- `/v1/self-service/branding/macos` — GET (Search for sorted and paged macOS branding configurations
), POST (Create a Self Service macOS branding configuration with the supplied
)
- `/v1/self-service/branding/macos/{id}` — DELETE (Delete the Self Service macOS branding configuration indicated by the provided id
), GET (Read a single Self Service macOS branding configuration indicated by the provided id
), PUT (Update a Self Service macOS branding configuration with the supplied details
)
- `/v1/self-service/settings` — GET (Get an object representation of Self Service settings
), PUT (Put an object representation of Self Service settings
)
- `/v1/self-service/settings/history` — GET (Get a page of Self Service settings history
), POST (Add Self Service settings history notes
)

## self-service-plus

- `/v1/self-service-plus/feature-toggle/enabled` — GET (Determines if Self Service Plus feature toggle is enabled.)
- `/v1/self-service-plus/settings` — GET (Get Self Service Plus settings.), PUT (Save Self Service Plus settings.)

## service-discovery-enrollment

- `/v1/service-discovery-enrollment/well-known-settings` — GET (Get service discovery well-known settings for all organizations), PUT (Update service discovery well-known settings)

## settings

- `/settings/issueTomcatSslCertificate` — POST (Generate a SSL Certificate using Jamf Certificate Authority
)
- `/settings/obj/policyProperties` — GET (Get Policy Properties object
), PUT (Update Policy Properties object
)

## sites

- `/v1/sites` — GET (Find all sites
)
- `/v1/sites/{id}/objects` — GET (Find and filter site objects for a site ID
)

## slasa

- `/v1/slasa` — GET (Get the status of SLASA), POST (Accept the SLASA)

## smart-computer-groups

- `/v1/smart-computer-groups/{id}/recalculate` — POST (Recalculate the smart group for the given id
)

## smart-mobile-device-groups

- `/v1/smart-mobile-device-groups/{id}/recalculate` — POST (Recalculate a smart group for the given id then return the ids for the devices in the smart group
)

## smart-user-groups

- `/v1/smart-user-groups/{id}/recalculate` — POST (Recalculate the smart group for the given id and then return the ids for the users in the smart group
)

## smtp-server

- `/v1/smtp-server/history` — GET (Get specified SMTP Server history object
), POST (Add SMTP Server history object notes
)
- `/v1/smtp-server/test` — POST (Test functionality of an SMTP Server)
- `/v2/smtp-server` — GET (Finds the Jamf Pro SMTP Server information
), PUT (Updates Jamf Pro SMTP Server information
)
- `/v2/smtp-server/allowed-auth-types` — GET (Get allowed SMTP authentication types
)

## sso

- `/v1/sso/failover` — GET (Retrieve the current failover settings)
- `/v1/sso/failover/generate` — POST (Regenerates failover url)
- `/v2/sso/cert` — DELETE (Delete the currently configured certificate used by SSO
), GET (Retrieve the certificate currently configured for use with SSO
), POST (Jamf Pro will generate a new certificate and use it to sign SSO
), PUT (Update the certificate used by Jamf Pro to sign SSO requests to the identify provider
)
- `/v2/sso/cert/download` — GET (Download the certificate currently configured for use with Jamf Pro's SSO configuration
)
- `/v2/sso/cert/parse` — POST (Parse the certificate to get details about certificate type and keys needed to upload certificate file
)
- `/v3/sso` — GET (Retrieve the current Single Sign On configuration settings
), PUT (Updates the current Single Sign On configuration settings
)
- `/v3/sso/dependencies` — GET (Retrieve the list of Enrollment Customizations using SSO
)
- `/v3/sso/disable` — POST (Disable SSO
)
- `/v3/sso/history` — GET (Get SSO history object
), POST (Add SSO history object notes
)
- `/v3/sso/metadata/download` — GET (Download the Jamf Pro SAML metadata file
)

## startup-status

- `/startup-status` — GET (Retrieve information about application startup
)

## static-user-groups

- `/v1/static-user-groups` — GET (Return a list of all Static User Groups
)
- `/v1/static-user-groups/{id}` — GET (Return a specific Static User Group by id
)

## supervision-identities

- `/v1/supervision-identities` — GET (Search for sorted and paged Supervision Identities
), POST (Create a Supervision Identity for the supplied information
)
- `/v1/supervision-identities/upload` — POST (Upload the Supervision Identity .p12 file
)
- `/v1/supervision-identities/{id}` — DELETE (Delete a Supervision Identity with the supplied id
), GET (Retrieve a Supervision Identity with the supplied id
), PUT (Update a Supervision Identity with the supplied information
)
- `/v1/supervision-identities/{id}/download` — GET (Download the Supervision Identity .p12 file
)

## system

- `/v1/system/initialize` — POST (Set up fresh installed Jamf Pro Server
)
- `/v1/system/initialize-database-connection` — POST (Provide Database Password during startup
)
- `/v1/system/platform-initialize` — POST (Set up fresh installed Jamf Pro Server for Platform
)

## teacher-app

- `/v1/teacher-app` — GET (Get the Jamf Teacher settings that you have access to see
), PUT (Update a Jamf Teacher settings object
)
- `/v1/teacher-app/history` — GET (Get Jamf Teacher app settings history
), POST (Add Jamf Teacher app settings history notes
)

## time-zones

- `/v1/time-zones` — GET (Return information about the currently supported Time Zones
)

## user

- `/user` — GET (Return all Jamf Pro user acounts
)
- `/user/updateSession` — POST (Update values in the User's current session
)
- `/v1/user/change-password` — POST (Changes the user account password.
)
- `/v1/user/preferences/settings/{keyId}` — GET (Get the user preferences for the authenticated user and key.
)
- `/v1/user/preferences/{keyId}` — DELETE (Remove specified setting for authenticated user
), GET (Get the user setting for the authenticated user and key
), PUT (Persist the user setting
)

## user-sessions

- `/v1/user-sessions/active` — GET (Get active user sessions.
)
- `/v1/user-sessions/count` — GET (Get count of active user sessions.
)

## users

- `/v1/users` — GET (Retrieve users with pagination and filtering), POST (Create a new user in inventory)
- `/v1/users/{id}` — DELETE (Delete a user from inventory), GET (Retrieve a user by ID), PUT (Update a user in inventory)
- `/v1/users/{id}/recalculate-smart-groups` — POST (Recalculate a smart group for the given user id and then return the count of smart groups the user falls into
)

## volume-purchasing-locations

- `/v1/volume-purchasing-locations` — GET (Retrieve Volume Purchasing Locations), POST (Create a Volume Purchasing Location)
- `/v1/volume-purchasing-locations/{id}` — DELETE (Delete a Volume Purchasing Location with the supplied id), GET (Retrieve a Volume Purchasing Location with the supplied id), PATCH (Update a Volume Purchasing Location)
- `/v1/volume-purchasing-locations/{id}/content` — GET (Retrieve the Volume Purchasing Content for the Volume Purchasing Location with the supplied id)
- `/v1/volume-purchasing-locations/{id}/history` — GET (Get specified Volume Purchasing Location history object
), POST (Add specified Volume Purchasing Location history object notes
)
- `/v1/volume-purchasing-locations/{id}/reclaim` — POST (Reclaim a Volume Purchasing Location with the supplied id)
- `/v1/volume-purchasing-locations/{id}/revoke-licenses` — POST (Revoke licenses for a Volume Purchasing Location with the supplied id)

## volume-purchasing-subscriptions

- `/v1/volume-purchasing-subscriptions` — GET (Retrieve Volume Purchasing Subscriptions), POST (Create a Volume Purchasing Subscription)
- `/v1/volume-purchasing-subscriptions/{id}` — DELETE (Delete a Volume Purchasing Subscription with the supplied id), GET (Retrieve a Volume Purchasing Subscription with the supplied id), PUT (Update a Volume Purchasing Subscription)
- `/v1/volume-purchasing-subscriptions/{id}/history` — GET (Get specified Volume Purchasing Subscription history object
), POST (Add Volume Purchasing Subscription history object notes
)
