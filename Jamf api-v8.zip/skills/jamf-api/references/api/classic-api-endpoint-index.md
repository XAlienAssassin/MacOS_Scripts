# Jamf Classic API — Endpoint Index

Swagger 2.0 spec, legacy XML/JSON API (base path `/JSSResource/`). Some object types (Advanced Computer Searches, static Computer Groups, Computer History) are Classic-API-only and have no Pro API equivalent yet.

Total endpoints: 273.

---

## accounts

- `/accounts` — GET (Finds all accounts)
- `/accounts/groupid/{id}` — DELETE (Deletes a group by id), GET (Finds groups by id), POST (Creates a new group by id), PUT (Updates an existing group by id)
- `/accounts/groupname/{name}` — GET (Finds groups by name)
- `/accounts/userid/{id}` — DELETE (Deletes a user by id), GET (Finds users by id), POST (Creates a new user by id), PUT (Updates an existing user by id)
- `/accounts/username/{name}` — GET (Finds users by name)

## activationcode

- `/activationcode` — GET (Finds the Jamf Pro activation code), PUT (Updates the Jamf Pro activation code)

## advancedcomputersearches

- `/advancedcomputersearches` — GET (Finds all advanced computer searches)
- `/advancedcomputersearches/id/{id}` — DELETE (Deletes a computer search by id), GET (Finds computer searches by id), POST (Creates a new advanced computer search by id), PUT (Updates an existing advanced computer search by id)
- `/advancedcomputersearches/name/{name}` — GET (Finds computer searches by name)

## advancedmobiledevicesearches

- `/advancedmobiledevicesearches` — GET (Finds all advanced mobile device searches)
- `/advancedmobiledevicesearches/id/{id}` — DELETE (Deletes a mobile device search by id), GET (Finds mobile device searches by id), POST (Creates a new advanced mobile device search by id), PUT (Updates an existing advanced mobile device search by id)
- `/advancedmobiledevicesearches/name/{name}` — GET (Finds mobile device searches by name)

## advancedusersearches

- `/advancedusersearches` — GET (Finds all advanced user searches)
- `/advancedusersearches/id/{id}` — DELETE (Deletes a user search by id), GET (Finds user searches by id), POST (Creates a new advanced user search by id), PUT (Updates an existing advanced user search by id)
- `/advancedusersearches/name/{name}` — GET (Finds user searches by name)

## allowedfileextensions

- `/allowedfileextensions` — GET (Finds the allowed file extension)
- `/allowedfileextensions/extension/{extension}` — GET (Finds an allowed file extension value by name)
- `/allowedfileextensions/id/{id}` — DELETE (Deletes an allowed file extension value by id), GET (Finds an allowed file extension value by id), POST (Creates a new allowed file extension value by id)

## buildings

- `/buildings` — GET (Finds all buildings)
- `/buildings/id/{id}` — DELETE (Deletes a building by id), GET (Finds buildings by id), POST (Creates a new building by id), PUT (Updates an existing building by id)
- `/buildings/name/{name}` — GET (Finds buildings by name)

## categories

- `/categories` — GET (Finds all categories)
- `/categories/id/{id}` — DELETE (Deletes a category by id), GET (Finds categories by id), POST (Creates a new category by id), PUT (Updates an existing category by id)
- `/categories/name/{name}` — GET (Finds categories by name)

## classes

- `/classes` — GET (Finds all classes)
- `/classes/id/{id}` — DELETE (Deletes a class by id), GET (Finds classes by id), POST (Creates a new class by id.  The mobile device list is not used in the POST, the mobile device group is used instead.), PUT (Updates an existing class by id.  The mobile device list is not used in the POST, the mobile device group is used instead.)
- `/classes/name/{name}` — GET (Finds classes by name)

## commandflush

- `/commandflush` — DELETE (Flushes commands based on information specified in an XML file.)
- `/commandflush/{idtype}/id/{id}/status/{status}` — DELETE (Flushes commands for computers, computergroups, mobiledevices, or mobiledevicegroups.)

## computerapplications

- `/computerapplications/application/{application}` — GET (Finds computer applications by name)
- `/computerapplications/application/{application}/inventory/{inventory}` — GET (Finds computer applications by name and generates additional inventory display)
- `/computerapplications/application/{application}/version/{version}` — GET (Finds computer applications by name and version)
- `/computerapplications/application/{application}/version/{version}/inventory/{inventory}` — GET (Finds computer applications by name and version, and generates additional inventory display)

## computerapplicationusage

- `/computerapplicationusage/id/{id}/{start_date}_{end_date}` — GET (Finds computer application usage by computer id)
- `/computerapplicationusage/macaddress/{macaddress}/{start_date}_{end_date}` — GET (Finds computer application usage by computer mac address)
- `/computerapplicationusage/name/{name}/{start_date}_{end_date}` — GET (Finds computer application usage by computer name)
- `/computerapplicationusage/serialnumber/{serialnumber}/{start_date}_{end_date}` — GET (Finds computer application usage by computer serial number)
- `/computerapplicationusage/udid/{udid}/{start_date}_{end_date}` — GET (Finds computer application usage by computer UDID)

## computercheckin

- `/computercheckin` — GET (Finds the Jamf Pro computer checkin information), PUT (Updates the Jamf Pro computer checkin information)

## computercommands

- `/computercommands` — GET (Finds all computer commands)
- `/computercommands/command/{command}` — POST (Creates a new computer command. Commands supported: UnlockUserAccount(UnlockUserAccount deprecated on 2025-07-07), EnableRemoteDesktop (macOS 10.14.4 and later) (EnableRemoteDesktop Deprecated on 2025-07-10), DisableRemoteDesktop (macOS 10.14.4 and later), (DisableRemoteDesktop Deprecated on 2025-07-10))
- `/computercommands/command/{command}/id/{id}` — POST (Creates a new computer command. Commands supported: EnableRemoteDesktop (macOS 10.14.4 and later) (EnableRemoteDesktop Deprecated on 2025-07-10), DisableRemoteDesktop (macOS 10.14.4 and later) (DisableRemoteDesktop Deprecated on 2025-07-10))
- `/computercommands/name/{name}` — GET (Finds matching computer commands by name.)
- `/computercommands/status/{statusuuid}` — GET (Finds a computer command status by uuid)
- `/computercommands/uuid/{uuid}` — GET (Finds a computer command by uuid)

## computerextensionattributes

- `/computerextensionattributes` — GET (Finds all computer extension attributes)
- `/computerextensionattributes/id/{id}` — DELETE (Deletes a computer extension attribute by id), GET (Finds computer extension attributes by id), POST (Creates a new computer extension attribute by id), PUT (Updates an existing computer extension attribute by id)
- `/computerextensionattributes/name/{name}` — GET (Finds computer extension attributes by name)

## computergroups

- `/computergroups` — GET (Finds all computer groups)
- `/computergroups/id/{id}` — DELETE (Deletes a computer group by id), GET (Finds computer groups by id), POST (Creates a new computer group by id), PUT (Updates an existing computer group by id)
- `/computergroups/name/{name}` — GET (Finds computer groups by name)

## computerhardwaresoftwarereports

- `/computerhardwaresoftwarereports/id/{id}/{start_date}_{end_date}` — GET (Finds hardware/software reports by computer id)
- `/computerhardwaresoftwarereports/id/{id}/{start_date}_{end_date}/subset/{subset}` — GET (Display subsets of information for computer hardware/software history)
- `/computerhardwaresoftwarereports/macaddress/{macaddress}/{start_date}_{end_date}` — GET (Finds hardware/software reports by computer mac address)
- `/computerhardwaresoftwarereports/name/{name}/{start_date}_{end_date}` — GET (Finds hardware/software reports by computer name)
- `/computerhardwaresoftwarereports/serialnumber/{serialnumber}/{start_date}_{end_date}` — GET (Finds hardware/software reports by computer serial number)
- `/computerhardwaresoftwarereports/udid/{udid}/{start_date}_{end_date}` — GET (Finds hardware/software reports by computer UDID)

## computerhistory

- `/computerhistory/id/{id}` — GET (Finds computer history by id)
- `/computerhistory/id/{id}/subset/{subset}` — GET (Display subsets of information for a computer history)
- `/computerhistory/macaddress/{macaddress}` — GET (Finds computer history by mac address)
- `/computerhistory/name/{name}` — GET (Finds computer history by name)
- `/computerhistory/serialnumber/{serialnumber}` — GET (Finds computer history by serial number)
- `/computerhistory/udid/{udid}` — GET (Finds computer history by UDID)

## computerinventorycollection

- `/computerinventorycollection` — GET (Finds the Jamf Pro computer inventory collection information), PUT (Updates the Jamf Pro computer inventory collection information)

## computerinvitations

- `/computerinvitations` — GET (Finds all computer invitations)
- `/computerinvitations/id/{id}` — DELETE (Deletes a computer invitation by id), GET (Finds computer invitations by id), POST (Creates a new computer invitation by id)
- `/computerinvitations/invitation/{invitation}` — GET (Finds computer invitations by invitation)
- `/computerinvitations/name/{name}` — GET (Finds computer invitations by name)

## computermanagement

- `/computermanagement/id/{id}` — GET (Finds computer management information by id)
- `/computermanagement/id/{id}/patchfilter/{filter}` — GET (Display patch management information for a computer and filter)
- `/computermanagement/id/{id}/subset/{subset}` — GET (Display subsets of management information for a computer )
- `/computermanagement/id/{id}/username/{username}` — GET (Display management information for a computer and username)
- `/computermanagement/id/{id}/username/{username}/subset/{subset}` — GET (Display subsets of management information for a computer and username)
- `/computermanagement/macaddress/{macaddress}` — GET (Finds computer management information by mac address)
- `/computermanagement/name/{name}` — GET (Finds computer management information by name)
- `/computermanagement/serialnumber/{serialnumber}` — GET (Finds computer management information by serial number)
- `/computermanagement/udid/{udid}` — GET (Finds computer management information by UDID)

## computerreports

- `/computerreports` — GET (Finds all computer reports)
- `/computerreports/id/{id}` — GET (Finds computer reports by id)
- `/computerreports/name/{name}` — GET (Finds computer reports by name)

## computers

- `/computers` — GET (Finds all computers)
- `/computers/id/{id}` — DELETE (Deletes a computer by id), GET (Finds computers by id), POST (Creates a computer by specifying an id of 0), PUT (Updates an existing computer by id)
- `/computers/id/{id}/subset/{subset}` — GET (Display subsets of information for a computer)
- `/computers/macaddress/{macaddress}` — GET (Finds computers by mac address)
- `/computers/match/name/{matchname}` — GET (Searches for computers that match the provided name parameter)
- `/computers/match/{match}` — GET (Searches for computers that match the provided parameter)
- `/computers/name/{name}` — GET (Finds the first computer with the given name)
- `/computers/serialnumber/{serialnumber}` — GET (Finds computers by serial number)
- `/computers/subset/basic` — GET (Finds all computers)
- `/computers/udid/{udid}` — GET (Finds computers by UDID)

## departments

- `/departments` — GET (Finds all departments)
- `/departments/id/{id}` — DELETE (Deletes a department by id), GET (Finds departments by id), POST (Creates a new department by id), PUT (Updates an existing department by id)
- `/departments/name/{name}` — GET (Finds departments by name)

## directorybindings

- `/directorybindings` — GET (Finds all directory bindings)
- `/directorybindings/id/{id}` — DELETE (Deletes a directory binding by id), GET (Finds directory bindings by id), POST (Creates a new directory binding by id), PUT (Updates an existing directory binding by id)
- `/directorybindings/name/{name}` — GET (Finds directory bindings by name)

## diskencryptionconfigurations

- `/diskencryptionconfigurations` — GET (Finds all disk encryption configurations)
- `/diskencryptionconfigurations/id/{id}` — DELETE (Deletes a disk encryption configuration by id), GET (Finds disk encryption configurations by id), POST (Creates a new disk encryption configuration by id), PUT (Updates an existing disk encryption configuration by id)
- `/diskencryptionconfigurations/name/{name}` — GET (Finds disk encryption configurations by name)

## distributionpoints

- `/distributionpoints` — GET (Finds all distribution points)
- `/distributionpoints/id/{id}` — DELETE (Deletes a distribution point by id), GET (Finds distribution points by id), POST (Creates a new distribution point by id), PUT (Updates an existing distribution point by id)
- `/distributionpoints/name/{name}` — GET (Finds distribution points by name)

## dockitems

- `/dockitems` — GET (Finds all dock items)
- `/dockitems/id/{id}` — DELETE (Deletes a dock item by id), GET (Finds dock items by id), POST (Creates a new dock item by id), PUT (Updates an existing dock item by id)
- `/dockitems/name/{name}` — GET (Finds dock items by name)

## ebooks

- `/ebooks` — GET (Finds all ebooks)
- `/ebooks/id/{id}` — DELETE (Deletes an ebook by id), GET (Finds ebooks by id), POST (Creates a new ebook by id), PUT (Updates an existing ebook by id)
- `/ebooks/id/{id}/subset/{subset}` — GET (Display subsets of information for an ebook)
- `/ebooks/name/{name}` — GET (Finds ebooks by name)

## fileuploads

- `/fileuploads/{resource}/{idType}/{id}` — POST (Creates file attachments in Jamf Pro)

## gsxconnection

- `/gsxconnection` — GET (Finds the Jamf Pro GSX connection information), PUT (Updates the Jamf Pro GSX connection information)

## healthcarelistener

- `/healthcarelistener` — GET (Find all Healthcare Listener)
- `/healthcarelistener/id/{id}` — GET (Finds healthcare listener by id), PUT (Updates an existing healthcare listener by id)

## healthcarelistenerrule

- `/healthcarelistenerrule` — GET (Find all Healthcare Listener rules)
- `/healthcarelistenerrule/id/{id}` — GET (Finds Healthcare Listener rules by id), POST (Creates a new Healthcare Listener rule), PUT (Updates an existing Healthcare Listener rule by id)

## ibeacons

- `/ibeacons` — GET (Finds all iBeacon regions)
- `/ibeacons/id/{id}` — DELETE (Deletes an iBeacon region by id), GET (Finds iBeacon regions by id), POST (Creates a new iBeacon region by id), PUT (Updates an existing iBeacon region by id)
- `/ibeacons/name/{name}` — GET (Finds iBeacon regions by name)

## infrastructuremanager

- `/infrastructuremanager` — GET (Find all Infrastructure Managers)
- `/infrastructuremanager/id/{id}` — GET (Finds infrastructure manager by id), PUT (Updates an existing infrastructure manager by id)

## jsonwebtokenconfigurations

- `/jsonwebtokenconfigurations` — GET (Finds all JSON Web Token configurations)
- `/jsonwebtokenconfigurations/id/{id}` — DELETE (Deletes a JSON Web Token configuration by id), GET (Find JSON Web Token configuration by id), POST (Creates a new JSON Web Token configuration by id), PUT (Updates an existing JSON Web Token configuration by id)

## jssuser

- `/jssuser` — GET (Returns basic information about Jamf Pro, as well as privileges of the person requesting the resource.  Deprecated.)

## ldapservers

- `/ldapservers` — GET (Finds all ldapservers)
- `/ldapservers/id/{id}` — DELETE (Deletes a ldap server by id), GET (Finds ldap servers by id), POST (Creates a new ldap server by id), PUT (Updates an existing ldap server by id)
- `/ldapservers/id/{id}/group/{group}` — GET (Display information for matching groups for an ldap server)
- `/ldapservers/id/{id}/group/{group}/user/{user}` — GET (Display information about user membership in a group for an ldap server)
- `/ldapservers/id/{id}/user/{user}` — GET (Display information for matching users for an ldap server)
- `/ldapservers/name/{name}` — GET (Finds ldap servers by name)

## licensedsoftware

- `/licensedsoftware` — GET (Finds all licensed software)
- `/licensedsoftware/id/{id}` — DELETE (Deletes a computer command by id), GET (Finds licensed software by id), POST (Creates a new computer command by id), PUT (Updates an existing computer command by id)
- `/licensedsoftware/name/{name}` — GET (Finds licensed software by name)

## logflush

- `/logflush` — DELETE (Flushes a log specified in an XML file.)
- `/logflush/{log}/id/{id}/interval/{interval}` — DELETE (Flushes a log for a policy for a given interval listed in the URL.)
- `/logflush/{log}/interval/{interval}` — DELETE (Flushes a log for all policies for a given interval listed in the URL.)

## macapplications

- `/macapplications` — GET (Finds all mac applications)
- `/macapplications/id/{id}` — DELETE (Deletes a mac application by id), GET (Finds mac applications by id), POST (Creates a new mac application by id), PUT (Updates an existing mac application by id)
- `/macapplications/id/{id}/subset/{subset}` — GET (Display subsets of information for a mac application)
- `/macapplications/name/{name}` — GET (Finds mac applications by name)

## mobiledeviceapplications

- `/mobiledeviceapplications` — GET (Finds all mobile device applications)
- `/mobiledeviceapplications/bundleid/{bundleid}` — GET (Finds mobile device applications by bundle ID)
- `/mobiledeviceapplications/bundleid/{bundleid}/version/{version}` — GET (Finds mobile device applications by bundle ID and version)
- `/mobiledeviceapplications/id/{id}` — DELETE (Deletes a mobile device application by id), GET (Finds mobile device applications by id), POST (Creates a new mobile device application by id), PUT (Updates an existing mobile device application by id)
- `/mobiledeviceapplications/id/{id}/subset/{subset}` — GET (Display subsets of information for a mobile device application)
- `/mobiledeviceapplications/name/{name}` — GET (Finds mobile device applications by name)

## mobiledevicecommands

- `/mobiledevicecommands` — GET (Finds all mobile device commands)
- `/mobiledevicecommands/command` — POST (Creates a new mobile device command. Command and mobile device list specified in an XML file.  Commands supported: UpdateInventory(Update Inventory Deprecated on 2026-03-13), Wallpaper (supervised only) (Wallpaper Deprecated on 2026-03-13), PasscodeLockGracePeriod (shared iPad only) (PasscodeLockGracePeriod Deprecated on 2025-06-26), EnableLostMode (supervised only), DeviceLocation (supervised and in lost mode only)(DeviceLocation Deprecated on 2025-06-12), PlayLostModeSound (supervised and in lost mode only)(PlayLostModeSound Deprecated on 2025-06-12), RefreshCellularPlans(RefreshCellularPlans deprecated on 2025-07-15))
- `/mobiledevicecommands/command/DeviceName/{device_name}/id/{id_list}` — POST (Creates a new command to set the name of a mobile device.  Command and mobile device list specified in URL.  Command fails when another DeviceName command is pending. Use of a list of devices is generally not advised. (DeviceName Deprecated on 2024-06-27))
- `/mobiledevicecommands/command/ScheduleOSUpdate/{install_action}/id/{id_list}` — POST (Creates a new command to request that a mobile device update its OS. Command and mobile device list specified in URL. Device will be updated to the latest OS version based on device eligibility. (Deprecated 2022-10-17))
- `/mobiledevicecommands/command/ScheduleOSUpdate/{install_action}/{product_version}/id/{id_list}` — POST (Creates a new command to request that a mobile device update its OS. Command and mobile device list specified in URL. Mixing iOS and tvOS devices in ID list is not advised, as product version is specific to OS type. (Deprecated 2022-10-17))
- `/mobiledevicecommands/command/{command}` — GET (Finds all mobile device commands for specified command), POST (Creates a new mobile device command using command name. Command and mobile device list specified in an XML file.  Commands supported: UpdateInventory(Update Inventory Deprecated on 2026-03-13), Wallpaper (supervised only) (Wallpaper Deprecated on 2026-03-13), PasscodeLockGracePeriod (shared iPad only) (PasscodeLockGracePeriod Deprecated on 2025-06-26), EnableLostMode (supervised only), DeviceLocation (supervised and in lost mode only)(DeviceLocation Deprecated on 2025-06-12), PlayLostModeSound (supervised and in lost mode only)(PlayLostModeSound Deprecated on 2025-06-12))
- `/mobiledevicecommands/command/{command}/id/{id_list}` — POST (Creates a new mobile device command.  Command and mobile device list specified in URL.  Commands supported: UpdateInventory(Update Inventory Deprecated on 2026-03-13), Wallpaper (supervised only) (Wallpaper Deprecated on 2026-03-13), PasscodeLockGracePeriod (shared iPad only) (PasscodeLockGracePeriod Deprecated on 2025-06-26), EnableLostMode (supervised only), DeviceLocation (supervised and in lost mode only)(DeviceLocation Deprecated on 2025-06-12), PlayLostModeSound (supervised and in lost mode only)(PlayLostModeSound Deprecated on 2025-06-12))
- `/mobiledevicecommands/name/{name}` — GET (Finds all mobile device commands by name.  Same as command below.)
- `/mobiledevicecommands/uuid/{uuid}` — GET (Finds a mobile device command by uuid)

## mobiledeviceconfigurationprofiles

- `/mobiledeviceconfigurationprofiles` — GET (Finds all mobile device configuration profiles)
- `/mobiledeviceconfigurationprofiles/id/{id}` — DELETE (Deletes a mobile device configuration profile by id), GET (Finds mobile device configuration profiles by id), POST (Creates a new mobile device configuration profile by id), PUT (Updates an existing mobile device configuration profile by id)
- `/mobiledeviceconfigurationprofiles/id/{id}/subset/{subset}` — GET (Display subsets of information for a mobile device configuration profile)
- `/mobiledeviceconfigurationprofiles/name/{name}` — GET (Finds mobile device configuration profiles by name)

## mobiledeviceenrollmentprofiles

- `/mobiledeviceenrollmentprofiles` — GET (Finds all mobile device enrollment profiles)
- `/mobiledeviceenrollmentprofiles/id/{id}` — DELETE (Deletes a mobile device enrollment profile by id), GET (Finds mobile device enrollment profiles by id), POST (Creates a new mobile device enrollment profile by id), PUT (Updates an existing mobile device enrollment profile by id)
- `/mobiledeviceenrollmentprofiles/id/{id}/subset/{subset}` — GET (Display subsets of information for an enrollment profile)
- `/mobiledeviceenrollmentprofiles/invitation/{invitation}` — GET (Finds mobile device enrollment profiles by invitation)
- `/mobiledeviceenrollmentprofiles/name/{name}` — GET (Finds mobile device enrollment profiles by invitation)

## mobiledeviceextensionattributes

- `/mobiledeviceextensionattributes` — GET (Finds all mobile device extension attributes)
- `/mobiledeviceextensionattributes/id/{id}` — DELETE (Deletes a mobile device extension attribute by id), GET (Finds mobile device extension attributes by id), POST (Creates a new mobile device extension attribute by id), PUT (Updates an existing mobile device extension attribute by id)
- `/mobiledeviceextensionattributes/name/{name}` — GET (Finds mobiledeviceextensionattributes by name)

## mobiledevicegroups

- `/mobiledevicegroups` — GET (Finds all mobile device groups)
- `/mobiledevicegroups/id/{id}` — DELETE (Deletes a mobile device group by id), GET (Finds mobile device groups by id), POST (Creates a new mobile device group by id), PUT (Updates an existing mobile device group by id)
- `/mobiledevicegroups/name/{name}` — GET (Finds mobile device groups by name)

## mobiledevicehistory

- `/mobiledevicehistory/id/{id}` — GET (Finds mobile device history by id)
- `/mobiledevicehistory/id/{id}/subset/{subset}` — GET (Display subsets of information for a mobile device history)
- `/mobiledevicehistory/macaddress/{macaddress}` — GET (Finds mobile device history by wifi mac address)
- `/mobiledevicehistory/name/{name}` — GET (Finds mobile device history by name)
- `/mobiledevicehistory/serialnumber/{serialnumber}` — GET (Finds mobile device history by serial number)
- `/mobiledevicehistory/udid/{udid}` — GET (Finds mobile device history by UDID)

## mobiledeviceinvitations

- `/mobiledeviceinvitations` — GET (Finds all mobile device invitations)
- `/mobiledeviceinvitations/id/{id}` — DELETE (Deletes a mobile device invitation by id), GET (Finds mobile device invitations by id), POST (Creates a new mobile device invitation by id)
- `/mobiledeviceinvitations/invitation/{invitation}` — GET (Finds mobile device invitations by invitation)

## mobiledeviceprovisioningprofiles

- `/mobiledeviceprovisioningprofiles` — GET (Finds all mobile device provisioning profiles)
- `/mobiledeviceprovisioningprofiles/id/{id}` — DELETE (Deletes a mobile device provisioning profile by id), GET (Finds mobile device provisioning profiles by id), POST (Creates a new mobile device provisioning profile by id), PUT (Updates an existing mobile device provisioning profile by id)
- `/mobiledeviceprovisioningprofiles/id/{id}/subset/{subset}` — GET (Display subsets of information for a mobile device provisioning profile)
- `/mobiledeviceprovisioningprofiles/name/{name}` — GET (Finds mobile device provisioning profiles by name)
- `/mobiledeviceprovisioningprofiles/uuid/{uuid}` — GET (Finds mobile device provisioning profiles by uuid)

## mobiledevices

- `/mobiledevices` — GET (Finds all mobile devices)
- `/mobiledevices/id/{id}` — DELETE (Deletes a mobile device by id), GET (Finds mobile devices by id), POST (Creates a new mobile device by id), PUT (Updates an existing mobile device by id)
- `/mobiledevices/id/{id}/subset/{subset}` — GET (Display subsets of information for a mobile device)
- `/mobiledevices/macaddress/{macaddress}` — GET (Finds mobile devices by wifi mac address)
- `/mobiledevices/match/{match}` — GET (Searches for mobile devices that match the provided parameter)
- `/mobiledevices/name/{name}` — GET (Finds mobile devices by name)
- `/mobiledevices/serialnumber/{serialnumber}` — GET (Finds mobile devices by serial number)
- `/mobiledevices/udid/{udid}` — GET (Finds mobile devices by UDID)

## networksegments

- `/networksegments` — GET (Finds all network segments)
- `/networksegments/id/{id}` — DELETE (Deletes a network segment by id), GET (Finds network segments by id), POST (Creates a new network segment by id), PUT (Updates an existing network segment by id)
- `/networksegments/name/{name}` — GET (Finds network segments by name)

## osxconfigurationprofiles

- `/osxconfigurationprofiles` — GET (Finds all OS X configuration profiles)
- `/osxconfigurationprofiles/id/{id}` — DELETE (Deletes a OS X configuration profile by id), GET (Finds OS X configuration profiles by id), POST (Creates a new OS X configuration profile by id), PUT (Updates an existing OS X configuration profile by id)
- `/osxconfigurationprofiles/id/{id}/subset/{subset}` — GET (Display subsets of information for an OS X configuration profile)
- `/osxconfigurationprofiles/name/{name}` — GET (Finds OS X configuration profiles by name)

## packages

- `/packages` — GET (Finds all packages)
- `/packages/id/{id}` — DELETE (Deletes a package by id), GET (Finds packages by id), POST (Creates a new package by id), PUT (Updates an existing package by id)
- `/packages/name/{name}` — GET (Finds packages by name)

## patchavailabletitles

- `/patchavailabletitles/sourceid/{id}` — GET (Finds all available title from a source by Id)

## patches

- `/patches` — GET (Finds all patches (Deprecated). Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations".)
- `/patches/id/{id}` — DELETE (Deletes a Patch Software Title by ID (Deprecated). Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations/{id}".), GET (Finds patches by ID (Deprecated). Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations/{id}".), POST (Creates new patches by ID (Deprecated). Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations".), PUT (Updates a Patch Software Title by ID (Deprecated). Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations/{id}".)
- `/patches/id/{id}/version/{version}` — GET (Display computers on a specific version (Deprecated). Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations/{id}/definitions".)
- `/patches/name/{name}` — GET (Finds the first patch with the name provided (Deprecated). Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations/{id}".)

## patchexternalsources

- `/patchexternalsources` — GET (Finds all patch external sources)
- `/patchexternalsources/id/{id}` — GET (Finds a patch external source by Id), POST (Create a new patch external source by Id), PUT (Updates a patch external source by Id)
- `/patchexternalsources/name/{name}` — GET (Finds the first patch external source with the name provided)

## patchinternalsources

- `/patchinternalsources` — GET (Finds all patch internal sources)
- `/patchinternalsources/id/{id}` — GET (Finds a patch internal source by ID)
- `/patchinternalsources/name/{name}` — GET (Finds the first patch internal source with the name provided)

## patchpolicies

- `/patchpolicies` — GET (Finds all patch policies. (Deprecated). Please transition use to Jamf Pro API endpoint "/v2/patch-policies".)
- `/patchpolicies/id/{id}` — DELETE (Deletes a patch policy by id), GET (Finds a patch policy by id), PUT (Updates an existing patch policy by id)
- `/patchpolicies/id/{id}/subset/{subset}` — GET (Display subsets of information for a patch policy)
- `/patchpolicies/softwaretitleconfig/id/{softwaretitleconfigid}` — GET (Finds all patch policy by software title configuration id. (Deprecated). Please transition use to Jamf Pro API endpoint "/v2/patch-policies".), POST (Create a new patch policy by software title configuration id)

## patchreports

- `/patchreports/patchsoftwaretitleid/{id}` — GET (Finds patch reports by patch software title id. (Deprecated) Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations/{id}/patch-report".)
- `/patchreports/patchsoftwaretitleid/{id}/version/{version}` — GET (Display computers for a specific version of a patch report. (Deprecated) Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations/{id}/patch-report".)

## patchsoftwaretitles

- `/patchsoftwaretitles` — GET (Finds all patch software titles. (Deprecated) Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations".)
- `/patchsoftwaretitles/id/{id}` — DELETE (Deletes a patch software title by id. (Deprecated) Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations/{id}".), GET (Finds patch software titles by id. (Deprecated) Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations/{id}".), POST (Creates new patch software title by id. (Deprecated) Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations/{id}".), PUT (Updates a patch software title by id. (Deprecated) Please transition use to Jamf Pro API endpoint "/v2/patch-software-title-configurations/{id}".)

## peripherals

- `/peripherals` — GET (Finds all peripherals)
- `/peripherals/id/{id}` — DELETE (Deletes a peripheral by id), GET (Finds peripherals by id), POST (Creates a new peripheral by id), PUT (Updates an existing peripheral by id)
- `/peripherals/id/{id}/subset/{subset}` — GET (Display subsets of information for a peripheral)

## peripheraltypes

- `/peripheraltypes` — GET (Finds all peripheral types)
- `/peripheraltypes/id/{id}` — DELETE (Deletes a peripheral by id), GET (Finds peripheral types by id), POST (Creates a new peripheral by id), PUT (Updates an existing peripheral by id)

## policies

- `/policies` — GET (Finds all policies)
- `/policies/category/{category}` — GET (Finds all policies by category)
- `/policies/createdBy/{createdBy}` — GET (Finds all policies by type)
- `/policies/id/{id}` — DELETE (Deletes a policy by id), GET (Finds policies by id), POST (Creates a new policy by id), PUT (Updates an existing policy by id)
- `/policies/id/{id}/subset/{subset}` — GET (Display subsets of information for a policy)
- `/policies/name/{name}` — GET (Finds policies by name)

## printers

- `/printers` — GET (Finds all printers)
- `/printers/id/{id}` — DELETE (Deletes a printer by id), GET (Finds printers by id), POST (Creates a new printer by id), PUT (Updates an existing printer by id)
- `/printers/name/{name}` — GET (Finds printers by name)

## removablemacaddresses

- `/removablemacaddresses` — GET (Finds all removablemacaddresses)
- `/removablemacaddresses/id/{id}` — DELETE (Deletes a removableMacAddress by id), GET (Finds removablemacaddresses by id), POST (Creates a new removableMacAddress by id), PUT (Updates an existing removableMacAddress by id)
- `/removablemacaddresses/name/{name}` — GET (Finds removablemacaddresses by name)

## restrictedsoftware

- `/restrictedsoftware` — GET (Finds all restricted software)
- `/restrictedsoftware/id/{id}` — DELETE (Deletes a restricted software by id), GET (Finds restricted software by id), POST (Creates a new restricted software by id), PUT (Updates an existing restricted software by id)
- `/restrictedsoftware/name/{name}` — GET (Finds restricted software by name)

## savedsearches

- `/savedsearches` — GET (Finds all saved searches (deprecated).  advancedcomputersearches and advancedmobiledevicesearches should be used instead of savedsearches.)
- `/savedsearches/id/{id}` — GET (Finds saved searches by id)
- `/savedsearches/name/{name}` — GET (Finds saved searches by name)

## scripts

- `/scripts` — GET (Finds all scripts)
- `/scripts/id/{id}` — DELETE (Deletes a script by id), GET (Finds scripts by id), POST (Creates a new script by id), PUT (Updates an existing script by id)
- `/scripts/name/{name}` — GET (Finds scripts by name)

## sites

- `/sites` — GET (Finds all sites)
- `/sites/id/{id}` — DELETE (Deletes a site by id), GET (Finds sites by id), POST (Creates a new site by id), PUT (Updates an existing site by id)
- `/sites/name/{name}` — GET (Finds sites by name)

## smtpserver

- `/smtpserver` — GET (Finds the Jamf Pro smtp server information), PUT (Updates the Jamf Pro smtp server information)

## softwareupdateservers

- `/softwareupdateservers` — GET (Finds all software update servers)
- `/softwareupdateservers/id/{id}` — DELETE (Deletes a software update server by id), GET (Finds software update servers by id), POST (Creates a new software update server by id), PUT (Updates an existing software update server by id)
- `/softwareupdateservers/name/{name}` — GET (Finds software update servers by name)

## userextensionattributes

- `/userextensionattributes` — GET (Finds all user extension attributes)
- `/userextensionattributes/id/{id}` — DELETE (Deletes a user extension attribute by id), GET (Finds user extension attributes by id), POST (Creates a new user extension attribute by id), PUT (Updates an existing user extension attribute by id)
- `/userextensionattributes/name/{name}` — GET (Finds user extension attributes by name)

## usergroups

- `/usergroups` — GET (Finds all user groups)
- `/usergroups/id/{id}` — DELETE (Deletes user groups by id), GET (Finds user groups by id), POST (Creates user groups by id), PUT (Updates user groups by id)
- `/usergroups/name/{name}` — GET (Finds user groups by name)

## users

- `/users` — GET (Finds all users)
- `/users/email/{email}` — GET (Finds users by email address)
- `/users/id/{id}` — DELETE (Deletes a user by id), GET (Finds users by id), POST (Creates a new user by id), PUT (Updates an existing user by id)
- `/users/name/{name}` — GET (Finds users by name)

## vppaccounts

- `/vppaccounts` — GET (Finds all VPP Accounts)
- `/vppaccounts/id/{id}` — DELETE (Deletes a vpp account by id), GET (Finds VPP Account by id), POST (Creates a new vpp account by id), PUT (Updates a vpp account by id)

## vppassignments

- `/vppassignments` — GET (Finds all VPP Assignments)
- `/vppassignments/id/{id}` — DELETE (Deletes a vpp assignment by id), GET (Finds VPP Assignment by id), POST (Creates a new vpp assignment by id), PUT (Updates a vpp assignment by id)

## vppinvitations

- `/vppinvitations` — GET (Finds all VPP Invitations)
- `/vppinvitations/id/{id}` — DELETE (Deletes a vpp invitation by id), GET (Finds VPP Invitation by id), POST (Creates a new vpp invitation by id), PUT (Updates a vpp invitation by id)
- `/vppinvitations/id/{id}/subset/{subset}` — GET (Display subsets of information for a VPP invitation)

## webhooks

- `/webhooks` — GET (Finds all webhooks)
- `/webhooks/id/{id}` — DELETE (Deletes a webhook by id), GET (Finds webhooks by id), POST (Creates a new webhook by id), PUT (Updates an existing webhook by id)
- `/webhooks/name/{name}` — GET (Finds webhooks by name)
