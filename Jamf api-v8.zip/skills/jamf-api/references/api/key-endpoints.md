# Key Jamf API Endpoints — Redeploy & Auto-Exclusion Workflow

Curated, human-readable detail for the endpoints this user's environment actually uses —
the redeploy-by-history workflow and its Hyperautomation port (with the permanent-exclusion
group logic added). All entries below were pulled and verified directly from the bundled
`jamf-pro-api-openapi.json` and `jamf-classic-api-swagger.yaml` specs, not from general
training knowledge. For anything not covered here, use
`scripts/query_jamf_api.py --search <term>` then `--path <exact path>`.

**For any "403 INVALID_PRIVILEGE" error on an endpoint not covered below**, don't guess at
the privilege name — Jamf publishes authoritative endpoint-to-privilege mapping tables:
- Pro API: https://developer.jamf.com/jamf-pro/docs/privileges-and-deprecations
- Classic API: https://developer.jamf.com/jamf-pro/docs/classic-api-minimum-required-privileges-and-endpoint-mapping

`web_fetch` the relevant page and search its table for the exact path — this is faster and
more reliable than inferring from Jamf's general privilege-naming conventions (which is
how the privileges documented below were first guessed at, before these pages were found).

Two APIs, two auth models — **don't mix them up**:
- **Pro API** (`/v1/`, `/v2/`... prefixes) — OAuth 2.0 client credentials via API Roles &
  Clients (this user's Hyperautomation Jamf connection uses this), or basic-auth token
  exchange via `/v1/auth/token`. JSON in/out.
- **Classic API** (no version prefix, base path `/JSSResource/`) — Bearer token (can reuse
  a Pro API token) or basic auth. XML in/out by default (`Accept`/`Content-Type` headers
  control this; `application/json` is also listed as supported).

> **Correction (confirmed by a live 404 in the redeploy call, not caught when this doc was
> first written): every Pro API path in this file needs an `/api` prefix on the actual
> request URL.** The OpenAPI spec's `servers` field is `/api`, and every `/v1/...` path
> below is relative to that root — so `POST /v1/jamf-management-framework/redeploy/{id}`
> must actually be requested as `POST /api/v1/jamf-management-framework/redeploy/{id}`.
> The Classic API has no such prefix (`/JSSResource/...` is already the full path). This
> doc's headers below still read `/v1/...` for brevity/searchability, matching the spec's
> own path keys — always prepend `/api` when actually building the request URL for any
> Pro API endpoint. The computers-inventory calls in this user's workflow already had this
> right by trial and error before the mistake was caught on the redeploy endpoint.

## Contents
- [POST /v1/oauth/token (OAuth 2.0 client credentials — what the Hyperautomation connection uses)](#post-v1oauthtoken-oauth-20-client-credentials--what-the-hyperautomation-connection-uses)
- [POST /v1/auth/token (basic-auth token exchange — what the legacy script uses)](#post-v1authtoken-basic-auth-token-exchange--what-the-legacy-script-uses)
- [GET /computerhistory/id/{id} — Classic](#get-computerhistoryidid--classic)
- [GET /advancedcomputersearches/id/{id} — Classic](#get-advancedcomputersearchesidid--classic)
- [GET /v1/computers-inventory/{id} — Pro](#get-v1computers-inventoryid--pro)
- [POST /v1/jamf-management-framework/redeploy/{id} — Pro](#post-v1jamf-management-frameworkredeployid--pro)
- [PUT /computergroups/id/{id} — Classic (the exclusion-group step)](#put-computergroupsidid--classic-the-exclusion-group-step)
- [Newer alternative: /v4/computers-inventory/{id} actions](#newer-alternative-v4computers-inventoryid-actions)
- [Destructive/high-impact endpoints (handle with care)](#destructivehigh-impact-endpoints)

---

## POST /v1/oauth/token (OAuth 2.0 client credentials — what the Hyperautomation connection uses)

This is the endpoint the user's already-configured Jamf Hyperautomation connection
authenticates against (API Role + API Client → Client ID + Client Secret). Body is
`application/x-www-form-urlencoded`:

```
grant_type=client_credentials
client_id=<client id>
client_secret=<client secret>
scope=api-role:1 api-role:2   # optional — omit to get all roles assigned to this client
```

Response:

```json
{
  "access_token": "<jwt>",
  "token_type": "Bearer",
  "scope": "api-role:1 api-role:2",
  "expires_in": 60
}
```

Note `expires_in` is in **seconds** and reflects the `accessTokenLifetimeSeconds` value set
on the API Client (Jamf Pro → API Roles and Clients) — this drives how often a token needs
refreshing. Hyperautomation's own OAuth 2.0 connection type should handle this refresh
automatically; this is documented here for reference/troubleshooting, not because the
workflow needs to call it directly.

## POST /v1/auth/token (basic-auth token exchange — what the legacy script uses)

Exchanges basic-auth credentials for a bearer token (what the original
`RedeployJamfBinaryByHistory.sh` script does). Returns:

```json
{ "token": "<jwt>", "expires": "2020-04-21T21:09:31.626Z" }
```

Not needed for the Hyperautomation version of the workflow — the existing OAuth 2.0
connection handles token refresh automatically. Documented here because the original
script relies on it and the token is short-lived (script refreshes every 25 min to stay
under a 30-min expiry).

---

## GET /computerhistory/id/{id} — Classic

Returns full management history for a computer, including completed MDM commands. This is
where the script pulls `completed_epoch` / `completed_utc` per command to determine if the
MDM channel is still alive. No strict response schema in the spec (Classic API docs are
XML-first and light on detail) — the field names used in the original script
(`completed_epoch`, `completed_utc`, under `commands/completed/command`) should be treated
as verified-by-the-working-script, not by this spec file.

**Confirmed by live testing (Hyperautomation port, requested with `Accept: application/json`,
so the body needs `PARSE_JSON` like other Classic endpoints — see the
`sentinelone-hyperautomation` skill's key-endpoints/workflow notes):**
- Full path (parsed): `computer_history.commands.completed` — a flat JSON array (not the
  `{"size": N, "command": [...]}` wrapping XML mode produces for repeated elements).
- The array is **sorted newest-first** across every real computer tested (light history,
  hundreds of entries, and a completely empty one) — the most recent completed command is
  reliably `completed[0]`; no need to sort or scan for a max timestamp.
- A computer whose Jamf binary/MDM channel has never responded returns `completed: []`
  (confirmed on a real device with `pending` entries but zero completed ones) — guard for
  this before indexing `[0]`, since it errors rather than returning null/undefined.
- Sibling arrays `pending` and `failed` exist at the same level and follow the same
  shape (`name`, `status`, `issued`/`issued_epoch`/`issued_utc`, `last_push*`) — useful if a
  workflow ever needs to know a command was *attempted* but never completed, as distinct
  from never being attempted at all.

---

## GET /advancedcomputersearches/id/{id} — Classic

Returns the computer IDs (and any display fields configured) belonging to a saved Advanced
Computer Search. This is the entry point for both the original script and the workflow port.

---

## GET /v1/computers-inventory/{id} — Pro

**Required API Role privilege: `Read Computers`** — confirmed two ways: live testing in
this user's tenant (a request without it returns `403 INVALID_PRIVILEGE`), and Jamf's
own Privileges and Deprecations page
(https://developer.jamf.com/jamf-pro/docs/privileges-and-deprecations), which is the
authoritative source for privilege-to-endpoint mapping — not part of the OpenAPI spec
itself. Check that page directly for any endpoint's required privilege before guessing;
it's a searchable table covering the whole Pro API, not just the endpoints in this file.

Returns computer inventory. Confirmed field for the check-in-age logic:

- `general.lastContactTime` — ISO 8601 date-time (e.g. `"2018-10-31T18:04:13Z"`)
- `general.jamfBinaryVersion`, `general.platform`, `general.remoteManagement.managed`,
  `general.mdmCapable.capable`, `general.lastEnrolledDate`

Use `?section=GENERAL` to scope the response (or omit for General by default; multiple
`section=` query params are supported, e.g. `section=general&section=hardware`).

---

## POST /v1/jamf-management-framework/redeploy/{id} — Pro

**Required API Role privileges (both, per Jamf's own official Privileges and
Deprecations page — https://developer.jamf.com/jamf-pro/docs/privileges-and-deprecations
— confirmed, not inferred like the other privilege notes in this file):**
- `Send Computer Remote Command to Install Package`
- `Read Computer Check-In`

A request without both fails with `403 INVALID_PRIVILEGE`, same shape as the
`computers-inventory` 403 documented above.

Triggers a redeploy of the Jamf Management Framework (the binary) to the specified
computer via MDM. Single required parameter: `id` (path). This is the actual remediation
action — the whole point of the workflow.

---

## PUT /computergroups/id/{id} — Classic (the exclusion-group step)

**Required API Role privilege: `Update - Static Computer Groups`** (for static groups —
confirmed via Jamf's own Classic API Privilege Requirements page,
https://developer.jamf.com/jamf-pro/docs/classic-api-minimum-required-privileges-and-endpoint-mapping;
smart groups would need `Update - Smart Computer Groups` instead). Confirmed working in
this user's tenant.

Updates a **static** computer group's membership. Per the spec's own description field:

> PUT also works with a name. One or more computers can be added by using
> `<computer_additions>` instead of `<computers>`. One or more computers can be deleted by
> using `<computer_deletions>` instead of `<computers>`.

Example body to add a computer to the `Redeploy - Permanently Excluded` group:

```xml
<computer_group>
  <computer_additions>
    <computer>
      <id>{computer_id}</id>
    </computer>
  </computer_additions>
</computer_group>
```

The spec doesn't define a strict schema for this body (same Classic-API looseness as
`/computerhistory`) — this matches the pattern documented in the endpoint's own
description, but **test against one non-critical computer ID first** before relying on it
inside a loop.

---

## Newer alternative: /v4/computers-inventory/{id} actions

The Pro API's `/v4/computers-inventory/{id}` namespace has grown newer device-management
actions not present in `/v1` — e.g. `/v4/computers-inventory/{id}/remove-mdm-profile` and
`/v4/computers-inventory/{id}/erase`. Not used in this workflow, but worth knowing they
exist if a future redesign moves further away from the Classic API.

---

## Destructive/high-impact endpoints

Flag before wiring any of these into a workflow — they remove or wipe device data/enrollment:

- `DELETE /v1/computers-inventory/{id}` — removes the computer record entirely
- `POST /v4/computers-inventory/{id}/erase` — remote wipe
- `POST /v4/computers-inventory/{id}/remove-mdm-profile` — unenrolls the device from MDM
- `DELETE /advancedcomputersearches/id/{id}`, `DELETE /computergroups/id/{id}` — deletes
  saved searches/groups (not device-destructive, but breaks the workflow's own dependencies
  if run against the search/group this workflow relies on)

None of these are used in the redeploy-and-exclude workflow. Say so explicitly if a request
would add one.
